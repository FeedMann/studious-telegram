# Source and asset provenance

This package is a local modding/research deliverable, not an original-game distribution or an official release from the linked projects.

## User-linked repositories inspected

- [FacadeResearch/FacadeDecompilation](https://github.com/FacadeResearch/FacadeDecompilation), commit `f07cec4f2883cf51664dc9504c09d4c6e8ec442d`: incomplete native Windows frontend reference. Its repository points to the newer FacadeResearch host. The original engine/assets are still needed; it is not used as the running engine in our captures.
- [FeedMann/refactored-train](https://github.com/FeedMann/refactored-train), commit `8d7b068a9e71ee286da0d786c1ff196354d4a3d3`: packaged research/extraction notes, inspected as context rather than mistaken for a complete game.
- [FeedMann/musical-goggles](https://github.com/FeedMann/musical-goggles), commit `f27feb6bded0bc72e4349b3f44d2962d8124d5ad`: supplied OBJ C/README and packaged Trip/vase experiments. The supplied OBJ source's build/support assets were absent in the checked checkout.

## Additional implementation references

- [VideoGameSmash12/Facade](https://github.com/VideoGameSmash12/Facade), commit `8ccfbd3fdac5659db3aaa2adc93f0926d62fbd8c`: decompiled Java/ABL/Jess/API reference. We did not distribute/rebuild its entire source tree; the additive classes were compiled against the installed original game classes and original rt.jar.
- [SalsaAlex/facade_decomp](https://github.com/SalsaAlex/facade_decomp), commit `235ee3c897536e500c8f73611c4d3b89dc299598`: incomplete native-engine reference useful for interpreting original structures/projection. Addresses, signatures and constants used by Room Lab were checked against the supported original engine.
- [Archive.org installer metadata](https://archive.org/metadata/facade-installer-1.1b): the separately obtained original 1.1b installer used in this test environment was verified as 175523943 bytes, MD5 `9160a3dc72a9b6408764ef46f1795c40`, SHA-1 `23d26719477f50ef52cdd2402254fc8ab6424c3c`. The installer and extracted game files are not in this package. Users must obtain/install the original game separately.

## Rebuilt / new work

- Supplied Trip Twins and clickable-vase DLLs/launchers were rebuilt and tested, with their source retained in `source/`. Their fresh evidence is distinct from inherited repository screenshots.
- `source/obj-repaired/src/{obj_demo.c,obj_launcher.c}` are unchanged supplied files. Their SHA-256 values respectively are `f1ed29855d2a78f9f1666818433d7e3376e918c34232f6455d4c9786354f6353` and `201cc7f61d17d015093983c877bd79345127155ba52215840d6d98d79a5854ca`. The missing build script was reconstructed.
- `source/room-lab/` contains the new coordinated native loader/render/hit-test/launcher, additive Java bridge/WME/wrapper, procedural asset generator and build script. The render-only twin technique derives from the supplied Trip experiment. No original native Sprite geometry or original stock Java class is bundled.
- The **teal sofa**, lathed **vase**, colour atlas and **two wall prints** were generated procedurally in this session, without recovering or copying the missing Teto art. Poster patterns use fixed random seeds; they are original arbitrary decorative prints, not fetched third-party posters. The generator uses the system DejaVu Sans font; the poster images are rasterized and no font binary is redistributed.
- Upstream's filename `obj_demo/TetoStandee.obj` is hard-coded. Our compatibility file under that name is explicitly a **sofa**, with Z compressed for the overlay's ±10 range. The new Room Lab uses the full-depth sofa. This substitution must not be described as restoration of the original Teto asset.
- Every raw MP4 and its event/runtime proof in `evidence/` was produced in this session from the actual original game running under Wine/Xvfb. The separately delivered compilation adds scope cards/captions, not synthesized gameplay.

## Distribution boundaries

The original game engine, original stock class tree, bundled JRE, installer, original texture/audio files, and large third-party decompiler/IDA research dumps are excluded. Public availability on GitHub should not be assumed to grant a new license: third-party code retains its original provenance/terms, and no additional license is asserted over it here. Consult the original projects before republishing their code/assets. This package is not affiliated with or endorsed by the original game authors or upstream repository owners.
