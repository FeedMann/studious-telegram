# Façade mod lab — fresh tests and new room/Java experiment

## Bottom line

| Item | Result | What it really does |
|---|---|---|
| Supplied “second Trip” | Runs; fresh Xvfb A/B recording | One Trip AI, body/head rendered a second time. Not an independent character. |
| Supplied clickable vase | Runs; fresh mouse-click/F7 recording | Screen-fixed 3D-looking vase and local activation/wobble only; no Java gameplay integration upstream. |
| Supplied OBJ | Not complete as downloaded; reconstructed and tested | Original C loader/overlay works once built and given compatible OBJ/MTL/TGA. F7 visibility and F10 local “HI!”. Missing original Teto art was replaced by an explicitly labelled new sofa test asset. |
| New **Room Lab** | Native and additive Java integration implemented and runtime-tested | Original procedural sofa/vase + two wall posters in room coordinates; native camera projection, depth buffer, click hit testing, custom WME in the real Trip Java entity + JNI gaze request/ACK. |
| Linked native decompilation | Reference, not a runnable replacement | Incomplete Windows frontend; original game/engine/assets still required. |

All videos in this delivery are **new captures from this session**, not screenshots/videos inherited from the repositories. Read `TEST-RESULTS.md` for exact evidence and limitations.

## Which version should I launch?

Use **Room Lab** for the added room furniture/posters and Java-backed activation. Use the separate supplied experiments to reproduce their original, narrower features. **Run only one launcher/session at a time; don't stack their DLL hooks.**

### 1. Room Lab — new experiment

See `room-lab/README.md`. Copy the *contents* of `room-lab/install` into an existing supported **Facade game root**, preserving paths. Run:

```text
<Facade>\util\sources\facade\facade-room-lab.exe
```

This requires the original installed 1.1b game and its Java/audio/data; the mod archive does not include those. It adds its own EXE/DLL/assets and three classes in `util/classes/mod`; original stock files are not replaced.

- **Click vase:** triangle/depth hit → custom Java WME → native gaze request → HUD acknowledgement.
- **F5:** alternate staged camera; **F6:** optional staged apartment view; **F7:** added sofa/vase; **F8:** render twin; **F9:** posters.
- Defaults: live game camera, props/posters ON, staged view/twin OFF.
- Staging is explicitly labelled: Trip's pose is pinned and Grace's rendering is hidden. Java is not paused. This is a demonstration view, not ordinary gameplay.

### 2. Supplied Trip Twins

From `upstream-experiments/trip-twins`, copy `trip-twins-test.exe` and `TripTwins.dll` beside the installed original `animEngineDLL.dll` in `util/sources/facade`. Run **`trip-twins-test.exe`**.

- **F8:** duplicate on/off. **F9:** change duplicate side. **F6:** supplied staged view (pins Trip/changes camera/hides Grace rendering).
- The separate `frame-photo.exe 190 65` helper is optional diagnostic camera staging for that experiment; it was used in the fresh two-Trip recording. It is not a standalone game and is not needed for normal launching.
- The twin shares the original AI/state. A second rendered body does not add another Java entity, dialogue agent or independent collision/controller.

### 3. Supplied clickable vase

From `upstream-experiments/clickable-vase`, copy `facade-interactable-test.exe` and `FacadeInteractable.dll` beside the installed original engine. Run **`facade-interactable-test.exe`**.

- **Left-click** its overlay vase: local reaction. **F7:** show/hide. **F6:** supplied staged test view.
- This upstream click does not become a stock activation or enter Java working memory. Use Room Lab for the new Java bridge.

### 4. Reconstructed supplied OBJ

From `upstream-experiments/obj-repaired`, copy `facade-obj-test.exe`, `FacadeOBJ.dll`, and the complete `obj_demo` folder beside the original engine. Run **`facade-obj-test.exe`**.

- **F7:** show/hide. **F10:** local wobble/“HI!”.
- This remains a **fixed screen overlay**, with depth disabled. The test asset is a new sofa, not the missing Teto standee. See that folder's README for the reconstruction.

For every experiment, wait for loading, focus the game window, select a name, then press Enter. In the tested Wine/Xvfb environment, Escape exposed the name menu after black title transitions. Do not diagnose a crash from one black transition frame. The installed game's original runtime, data and audio must be complete.

## What “activation” means here

The new Room Lab click reaches real Java working memory and an existing JNI gaze command. It is **not** stock pickup, a native Sprite registration, added collision/navigation, a new ABL/Jess story beat, or a second autonomous Trip. The 49-slot stock activation packet is unchanged; object 1001 is a mod-specific ID. Existing story behaviors can override the gaze request.

So: yes, room-space imported geometry and Java-backed custom activation are feasible; no, adding an OBJ or a custom WME by itself does not make the stock story understand a new object.

## Workspace cleanup

The durable workspace keeps the mod source/assets/builds, the three specifically linked reference repositories, relevant disassembly/notes, fresh evidence, and final deliverables. Large ancillary native/Java research clones, redundant extracted research files, inherited screenshots and scratch diagnostics are moved under `.cache`, not mixed into the release. No original game assets, installer, engine DLL, bundled JRE, or stock class tree are redistributed. Existing user work outside this lab is not deleted.

The packaged source is in `source/`; convenience installation files are in `room-lab/install/`; optional supplied experiments are in `upstream-experiments/`. `PROVENANCE.md` records source commits and the test-asset substitution. Hashes are in `SHA256SUMS.txt`.
