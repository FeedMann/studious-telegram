# Fresh runtime tests — 14 October 2026

## Environment and reproducibility

- Debian 13 sandbox, 2 CPUs / approximately 1.9 GiB RAM, Wine 10.0 (32-bit prefix), Mesa software OpenGL (`LIBGL_ALWAYS_SOFTWARE=1`, `LP_NUM_THREADS=2`).
- Xvfb `:99` at 1280×900×24, Openbox, PulseAudio null sink `facade_test`; FFmpeg 7.1.5 captured X11 + the sink monitor.
- Actual original Façade 1.1b engine and bundled Java **1.4.2_06** ran. Game assets, Java backend and decoded audio were installed separately, not substituted by a mock renderer.
- Supported original `animEngineDLL.dll` SHA-256: `815337c6f7fe05da8a99b5f261a182142907cae6f21b915b03fe6a8c1581016c`. The hash was unchanged after all runs.
- Game client/capture: 1016×734 at X11 root offset `(4,30)`. Each raw capture is H.264 + AAC, 20 fps. The Room Lab monitor track measured effectively silent (-91 dBFS); these are visual/input/log proofs, not proof of audible dialogue or audio-device functionality. The original renderer's 1016×1016 viewport is clipped by the shorter client; the new renderer/hit test accounts for this.
- `work/record_*.py` in the workspace (and `source/test-tools` in the ZIP) contain the actual timestamped xdotool/FFmpeg action scripts. Each clip has a corresponding `*-events.json` and runtime log. These scripts have environment/window IDs specific to the tested Xvfb session; they are evidence/reproduction references, not universal installers.

## Fresh evidence, not inherited repository media

| File in `evidence/` | Duration | Actual demonstration | Scope |
|---|---:|---|---|
| `01-upstream-clickable-vase.mp4` | 20 s | Two real left-button clicks, F7 hide/show; local activations confirmed in runtime log | Supplied fixed-screen vase, local-only reaction; staged camera, Java not paused |
| `02-upstream-trip-twins.mp4` | 19 s | F8 duplicate OFF/ON, F9 side changes; visible original apartment/Trip | Supplied second rendering, **one AI**; F6 + `frame-photo 190 65` staging; Grace render hidden |
| `03-repaired-upstream-obj.mp4` | 20 s | Loaded 360 triangle vertices / 128×128 RGBA texture; F10 “HI!”/wobble twice, F7 hide/show; normal game camera turns | Unchanged supplied OBJ C, reconstructed build + original new sofa compatibility asset; fixed overlay, no staging or Java activation |
| `04-room-space-java.mp4` | 42 s | World sofa/vase/posters, two real mouse activations with Java ACK, negative clicks, visibility toggles, side-view parallax/occlusion, optional twin, actual live-camera input | New mod-owned room meshes; custom Java WME + JNI gaze request, **not** native pickup or a new actor |

The separately delivered **`facade-mod-demo.mp4`** is an annotated compilation of those fresh recordings with scope cards. The four raw clips in the ZIP have no added captions, cuts, speed changes or inserted game frames. Repository-supplied screenshots are not used as runtime proof. The compilation labels which behavior is merely local/overlay and which reaches Java.

## New Room Lab: verified outcomes

1. **Real original runtime:** the launcher accepted the exact engine hash, uniquely redirected the Java entry point in memory, installed checked native hooks, and started the additive wrapper on the bundled Java 1.4.2_06. The wrapper called the unchanged stock `facade.Main`.
2. **All four assets loaded:** vase 540 triangle vertices; sofa 360; each poster 6. `04-roomlab-runtime.log` records world transforms, projection/depth setup and projected vase bounds `(803.2,257.0)–(846.8,322.6)` in client pixels.
3. **Room-relative geometry:** F5 shifts the staged camera by 45 world units in X; sofa/vase/posters move with the room. `04-world-side.png` shows the original Trip in front of/occluding the new sofa. F6 was then disabled, real Right/Up game input changed the live view, and the props remained room-relative (`04-live-camera.png`). This is not a fixed viewport overlay.
4. **Real mouse activation → Java:** clicks at root `(829,320)` / client `(825,290)` produced native sequences 1 and 2. Hit testing recorded mesh depth `0.156689` versus final scene depth `0.156606`; both were accepted within the documented rasterization tolerance.
5. **Java working-memory verification:** `04-java-runtime.log` records `WME VERIFIED seq=1` and `seq=2`, entity `facade.characters.trip.java.Trip`, custom class `mod.RoomLabActivationWME`, object 1001, actor 2, target `(170,48,-210)`.
6. **Native command return / round trip:** the same Java log records both `setGazeTracking` JNI returns. The native log separately records both `JAVA ACK` receipts; the final acknowledgement file is exactly `2 1 1`. `04-java-ack-2.png` shows the actual HUD acknowledgement. This proves insertion and call return, not sustained gaze or story understanding.
7. **Negative interactions:** the off-triangle background click left sequence at 0. After the first activation, clicking the former vase location with F7 props OFF left sequence at 1. The second legitimate click advanced it to 2. Assertions and values are in `04-events.json`.
8. **Integrated toggles:** F7 sofa/vase, F9 posters, F8 coordinated twin, F5/F6 camera controls all appear in the raw clip and native log. Staging is explicitly labelled in the game HUD, pins the Trip pose and hides Grace rendering; Java continues running. Most of the demo is a staged view, not ordinary unscripted play.

## Guard/build checks

`04-launcher-guard-tests.json` contains real Wine executions against isolated test directories:

| Bad installation | Expected / actual exit | Result |
|---|---:|---|
| Fake, wrong-hash engine file | 2 / 2 | Refused before loading it |
| Correct original engine but missing Java wrapper | 3 / 3 | Refused before starting a game |
| Correct engine/classes but missing asset/config folder | 3 / 3 | Refused before starting a game |

Native Room Lab source compiled with MinGW x86 GCC 14, `-Wall -Wextra -Werror`. Additive Java compiled with ECJ 3.16 against the original installed classes/rt.jar, `-1.4 -target 1.4`; all three class files have major version **48**. The delivered Room Lab EXE/DLL match the final tested runtime binaries. Build command logs are included.

The two OBJ source files are byte-for-byte identical to `FeedMann/musical-goggles` at the recorded commit. Only its missing build/support assets were reconstructed. The hardcoded `TetoStandee.obj` now contains a clearly documented **new sofa test mesh**, not original Teto art; Z is compressed for the upstream overlay's ±10 clip range. This does not establish that the missing original standee package was complete or working as downloaded.

## What was NOT established

- No independently simulated second Trip, new Java character instance, new dialogue agent, separate navigation or story state.
- No mod mesh registered as a native Sprite, collision obstacle, stock pickup/hand target or stock 49-slot activation entry. The stock packet remains unchanged; custom ID 1001 is confined to this bridge.
- No new ABL/Jess story behavior consumes the custom WME. The existing gaze request is a narrow visible/native command; stock behaviors may override it. A custom WME alone does not teach the story a new object.
- No claim that either public native decompilation is a complete engine replacement, or that the entire public Java decompilation cleanly rebuilds.
- No native modern-Windows/PowerShell runtime test, arbitrary engine/resolution compatibility, full playthrough, every camera angle/OBJ exporter, other-mod stacking, or long-session stability test. Installation helpers are supplied but were not executed by Windows PowerShell here; runtime deployment used a manual copy under Wine.
- No claim that a black loading/title transition is a crash. Tests explicitly restored focus and selected a stock name before judging room output.

The original game/installer/engine/JRE/classes/art/audio are **not included** in the download. All game sessions were closed after evidence capture. Large auxiliary research/scratch material was moved to excluded cache directories, keeping the deliverable workspace focused.
