# Supplied OBJ experiment — reconstructed test package

The linked `FeedMann/musical-goggles` repository at commit `f27feb6bded0bc72e4349b3f44d2962d8124d5ad` has `obj_demo.c` and `obj_launcher.c`, but the advertised OBJ build script, binaries, and `obj_demo` support assets were missing. It was not launch-ready as downloaded.

Here the two supplied C files are **unchanged**. `build.sh` reconstructs the missing MinGW build. The original missing Teto art has **not** been recovered or invented: we use an original procedural sofa test mesh instead, saved as `TetoStandee.obj` solely because that filename is hard-coded upstream. Its Z is compressed to fit the upstream overlay's ±10 clip range. The new Room Lab package uses the full-depth version of the sofa instead.

## Install and launch

1. Install the original Façade 1.1b game separately.
2. Put `facade-obj-test.exe`, `FacadeOBJ.dll`, and the complete `obj_demo` folder together in the installed game's `util/sources/facade` directory, beside **original** `animEngineDLL.dll`.
3. Close other game/mod processes. Run **`facade-obj-test.exe`**, not the normal game launcher. The EXE checks the original engine hash.
4. Wait for loading; choose a name and press Enter. If Wine leaves a black transition/menu, focus the game, press Escape to expose the name menu, then select a name and press Enter. Do not treat a loading/transition frame as a crash.
5. **F7** hides/shows the OBJ. **F10** triggers the upstream local wobble/“HI!” greeting.

This OBJ is a **screen-space overlay**. The source explicitly disables depth testing and depth writes and uses fixed viewport coordinates. Its greeting is local mod code, **not Java, a stock object activation, or an autonomous character interaction**. The working test is proof of this narrower feature, not room placement.

Rebuild: `bash build.sh` with `i686-w64-mingw32-gcc`. Original engine/assets/classes are not included. Do not stack this DLL with Room Lab or the other experiments; run one launcher at a time.

For camera-relative, depth-tested meshes and a Java-backed click, use **Room Lab**, not this supplied overlay.
