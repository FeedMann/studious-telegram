#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
CC="${CC:-i686-w64-mingw32-gcc}"
mkdir -p bin
"$CC" -std=c11 -O2 -Wall -Wextra -shared -o bin/FacadeOBJ.dll src/obj_demo.c -lopengl32 -lgdi32 -luser32 -lm -static-libgcc
"$CC" -std=c11 -O2 -Wall -Wextra -mwindows -o bin/facade-obj-test.exe src/obj_launcher.c -ladvapi32 -luser32 -static-libgcc
