/*
 * Façade original-engine textured OBJ overlay prototype.
 *
 * The game's shipped animEngineDLL.dll is not replaced. This DLL patches the
 * original engine's GDI32 SwapBuffers import, then submits a small textured
 * OBJ in the engine's already-current legacy OpenGL context immediately before
 * each frame is presented. The first asset is a screen-space Teto fan standee,
 * not a room-anchored prop or an independently animated NPC.
 *
 * Version-specific addresses and ABI apply ONLY to original Façade 1.1b
 * animEngineDLL.dll SHA-256:
 * 815337c6f7fe05da8a99b5f261a182142907cae6f21b915b03fe6a8c1581016c
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <GL/gl.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#if !defined(__i386__)
#error This experiment requires 32-bit x86 Windows.
#endif

#define SWAPBUFFERS_IAT_RVA 0x9be790u
#define ENGINE_DLL_SHA256 "815337c6f7fe05da8a99b5f261a182142907cae6f21b915b03fe6a8c1581016c"
#define OBJ_FILE "obj_demo/TetoStandee.obj"
#define MAX_OBJ_POSITIONS 4096
#define MAX_OBJ_UVS 4096
#define MAX_OBJ_TRIANGLE_VERTICES 24576
#define MAX_LINE 4096

struct Vec3 { float x,y,z; };
struct UV { float u,v; };
struct DrawVertex { struct Vec3 p; struct UV uv; };
typedef BOOL (WINAPI *SwapBuffersFn)(HDC);

static unsigned char *engine_base;
static SwapBuffersFn original_swap_buffers;
static HANDLE input_worker;
static volatile LONG stop_worker;
static volatile LONG standee_visible=1;
static volatile LONG greet_until=0;
static volatile LONG logged_asset=0;
static int inited;
static int init_failed;
static struct DrawVertex mesh[MAX_OBJ_TRIANGLE_VERTICES];
static size_t mesh_count;
static GLuint standee_texture;

static void log_line(const char *message) {
    FILE *f=fopen("obj-demo.log","a");
    if(f) { fprintf(f,"%lu: %s\n",(unsigned long)GetTickCount(),message); fclose(f); }
}

static void path_dir(const char *path,char *out,size_t out_size) {
    const char *a=strrchr(path,'/');
    const char *b=strrchr(path,'\\');
    const char *last=a;
    if(b && (!last || b>last)) last=b;
    size_t n=last?(size_t)(last-path+1):0;
    if(n>=out_size) n=out_size-1;
    memcpy(out,path,n);out[n]=0;
}
static int join_path(char *out,size_t size,const char *directory,const char *name) {
    int n=snprintf(out,size,"%s%s",directory,name);
    return n>0 && (size_t)n<size;
}
static int parse_index_pair(char *token,int *v_index,int *uv_index) {
    char *end=NULL;
    long v=strtol(token,&end,10);
    if(end==token || *end!='/' || v<=0) return 0;
    char *uv_start=end+1;
    long uv=strtol(uv_start,&end,10);
    if(end==uv_start || uv<=0) return 0;
    *v_index=(int)v-1;*uv_index=(int)uv-1;
    return 1;
}
static int emit_face_vertex(struct DrawVertex *dst,const struct Vec3 *p,const struct UV *uv) {
    if(mesh_count>=MAX_OBJ_TRIANGLE_VERTICES) return 0;
    dst->p=*p;dst->uv=*uv;mesh_count++;return 1;
}

/* Intentional subset: v, vt, positive-index f v/vt[/vn], triangles/quads/ngons,
 * mtllib and the first map_Kd. Normals/smoothing groups are not needed for this
 * unlit, alpha-textured card. Negative OBJ indices are rejected rather than
 * guessed. */
static int load_mtl_texture_path(const char *obj_path,char *texture_path,size_t cap) {
    FILE *obj=fopen(obj_path,"rb");
    if(!obj) { log_line("Cannot open obj_demo/TetoStandee.obj");return 0; }
    char directory[MAX_PATH]={0},line[MAX_LINE],material_name[MAX_PATH]={0};
    path_dir(obj_path,directory,sizeof directory);
    while(fgets(line,sizeof line,obj)) {
        if(strncmp(line,"mtllib",6)==0 && (line[6]==' '||line[6]=='\t')) {
            char *s=line+6;while(*s==' '||*s=='\t')s++;
            s[strcspn(s,"\r\n")]=0;
            if(*s) { strncpy(material_name,s,sizeof material_name-1);break; }
        }
    }
    fclose(obj);
    if(!material_name[0]) { log_line("OBJ has no mtllib directive");return 0; }
    char mtl_path[MAX_PATH];
    if(!join_path(mtl_path,sizeof mtl_path,directory,material_name)) { log_line("MTL path too long");return 0; }
    FILE *mtl=fopen(mtl_path,"rb");
    if(!mtl) { log_line("OBJ material file not found");return 0; }
    char texture_name[MAX_PATH]={0};
    while(fgets(line,sizeof line,mtl)) {
        if(strncmp(line,"map_Kd",6)==0 && (line[6]==' '||line[6]=='\t')) {
            char *s=line+6;while(*s==' '||*s=='\t')s++;
            s[strcspn(s,"\r\n")]=0;
            if(*s) { strncpy(texture_name,s,sizeof texture_name-1);break; }
        }
    }
    fclose(mtl);
    if(!texture_name[0] || !join_path(texture_path,cap,directory,texture_name)) {
        log_line("MTL has no usable map_Kd image");return 0;
    }
    return 1;
}

static int load_obj(const char *path) {
    FILE *f=fopen(path,"rb");
    if(!f) { log_line("Could not open OBJ asset");return 0; }
    struct Vec3 positions[MAX_OBJ_POSITIONS];
    struct UV uvs[MAX_OBJ_UVS];
    size_t position_count=0,uv_count=0;
    char line[MAX_LINE];mesh_count=0;
    while(fgets(line,sizeof line,f)) {
        if(line[0]=='v' && line[1]==' ' ) {
            struct Vec3 p;
            if(position_count>=MAX_OBJ_POSITIONS || sscanf(line+2,"%f %f %f",&p.x,&p.y,&p.z)!=3) { fclose(f);log_line("OBJ position table overflow or malformed vertex");return 0; }
            positions[position_count++]=p;
        } else if(line[0]=='v' && line[1]=='t' && (line[2]==' '||line[2]=='\t')) {
            struct UV uv;
            if(uv_count>=MAX_OBJ_UVS || sscanf(line+3,"%f %f",&uv.u,&uv.v)!=2) { fclose(f);log_line("OBJ UV table overflow or malformed vt");return 0; }
            uvs[uv_count++]=uv;
        } else if(line[0]=='f' && (line[1]==' '||line[1]=='\t')) {
            int fv[64],ft[64],n=0;
            char *cursor=line+1;
            while(*cursor) {
                while(*cursor==' '||*cursor=='\t'||*cursor=='\r'||*cursor=='\n')cursor++;
                if(!*cursor || *cursor=='#')break;
                char *start=cursor;
                while(*cursor && *cursor!=' '&&*cursor!='\t'&&*cursor!='\r'&&*cursor!='\n'&&*cursor!='#')cursor++;
                char saved=*cursor;*cursor=0;
                if(n>=64 || !parse_index_pair(start,&fv[n],&ft[n])) { fclose(f);log_line("Unsupported/malformed OBJ face (need positive v/vt indices)");return 0; }
                if((size_t)fv[n]>=position_count || (size_t)ft[n]>=uv_count) { fclose(f);log_line("OBJ face index is outside its vertex/UV table");return 0; }
                n++;if(saved=='#')break;if(saved)*cursor=saved;
            }
            if(n<3) { fclose(f);log_line("OBJ face contains fewer than three corners");return 0; }
            for(int i=1;i<n-1;i++) {
                int fan[3]={0,i,i+1};
                for(int k=0;k<3;k++) {
                    int q=fan[k];
                    if(!emit_face_vertex(&mesh[mesh_count],&positions[fv[q]],&uvs[ft[q]])) { fclose(f);log_line("OBJ triangulation exceeded the safe vertex limit");return 0; }
                }
            }
        }
    }
    fclose(f);
    if(mesh_count<3) { log_line("OBJ contained no drawable faces");return 0; }
    return 1;
}

/* TGA: uncompressed true-colour type 2, 32-bit BGRA. The supplied texture is
 * bottom-left-origin, matching OpenGL's first-row convention. */
static unsigned char *load_tga_rgba(const char *path,int *width,int *height) {
    FILE *f=fopen(path,"rb");
    if(!f) { log_line("OBJ map_Kd image not found");return NULL; }
    unsigned char h[18];
    if(fread(h,1,sizeof h,f)!=sizeof h || h[1]!=0 || h[2]!=2 || h[16]!=32) { fclose(f);log_line("Texture must be an uncompressed 32-bit true-colour TGA");return NULL; }
    int w=h[12]|(h[13]<<8),ht=h[14]|(h[15]<<8);
    if(w<1||ht<1||w>2048||ht>2048) { fclose(f);log_line("TGA dimensions are outside safe limits");return NULL; }
    if(fseek(f,h[0],SEEK_CUR)!=0) { fclose(f);return NULL; }
    size_t bytes=(size_t)w*(size_t)ht*4;
    unsigned char *src=(unsigned char *)malloc(bytes),*rgba=(unsigned char *)malloc(bytes);
    if(!src||!rgba||fread(src,1,bytes,f)!=bytes) { free(src);free(rgba);fclose(f);log_line("Short/unreadable TGA pixel data");return NULL; }
    fclose(f);
    int top=(h[17]&0x20)!=0,right=(h[17]&0x10)!=0;
    for(int y=0;y<ht;y++) for(int x=0;x<w;x++) {
        int sx=right?(w-1-x):x;
        int sy=top?(ht-1-y):y;
        size_t from=((size_t)sy*w+sx)*4,to=((size_t)y*w+x)*4;
        rgba[to+0]=src[from+2];rgba[to+1]=src[from+1];rgba[to+2]=src[from+0];rgba[to+3]=src[from+3];
    }
    free(src);*width=w;*height=ht;return rgba;
}

static int initialize_asset(void) {
    if(inited) return !init_failed;
    inited=1;
    char texture_path[MAX_PATH];
    if(!load_obj(OBJ_FILE) || !load_mtl_texture_path(OBJ_FILE,texture_path,sizeof texture_path)) { init_failed=1;return 0; }
    int width=0,height=0;
    unsigned char *pixels=load_tga_rgba(texture_path,&width,&height);
    if(!pixels) { init_failed=1;return 0; }
    glGenTextures(1,&standee_texture);
    if(!standee_texture) { free(pixels);init_failed=1;log_line("OpenGL could not allocate a texture name");return 0; }
    glBindTexture(GL_TEXTURE_2D,standee_texture);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);
    glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,pixels);
    free(pixels);
    char message[256];snprintf(message,sizeof message,"Loaded %lu OBJ triangle vertices and %dx%d RGBA texture",(unsigned long)mesh_count,width,height);log_line(message);
    return 1;
}

static void pixel_quad(float x,float y,float w,float h) {
    glVertex2f(x,y);glVertex2f(x+w,y);glVertex2f(x+w,y+h);glVertex2f(x,y+h);
}
static void draw_hi_glyphs(float x,float y) {
    /* Tiny 5x7 built-in bitmap font: H, I, !. Used only for the greeting UI. */
    static const unsigned char glyph[3][7]={
        {17,17,17,31,17,17,17},
        {31,4,4,4,4,4,31},
        {4,4,4,4,4,0,4}
    };
    glDisable(GL_TEXTURE_2D);glColor4f(0.55f,0.05f,0.15f,1.0f);
    glBegin(GL_QUADS);
    for(int c=0;c<3;c++) for(int row=0;row<7;row++) for(int col=0;col<5;col++) {
        if(glyph[c][row]&(1<<(4-col))) {
            float px=x+c*14+col*2.2f;
            float py=y+(6-row)*2.2f;
            pixel_quad(px,py,2.0f,2.0f);
        }
    }
    glEnd();
}
static void draw_greeting_bubble(float center_x,float bottom_y) {
    float x=center_x-37.0f,y=bottom_y+178.0f;
    glDisable(GL_TEXTURE_2D);
    glColor4f(1.0f,0.97f,0.92f,0.98f);
    glBegin(GL_QUADS);pixel_quad(x,y,74,34);glEnd();
    glColor4f(0.53f,0.04f,0.15f,1.0f);glLineWidth(2.4f);
    glBegin(GL_LINE_LOOP);glVertex2f(x,y);glVertex2f(x+74,y);glVertex2f(x+74,y+34);glVertex2f(x,y+34);glEnd();
    glBegin(GL_TRIANGLES);glVertex2f(x+43,y);glVertex2f(x+54,y);glVertex2f(x+48,y-10);glEnd();
    draw_hi_glyphs(x+16,y+8);
}

static void draw_obj_overlay(void) {
    if(!InterlockedCompareExchange(&standee_visible,0,0)) return;
    if(!wglGetCurrentContext()) return;
    if(!initialize_asset()) {
        if(InterlockedCompareExchange(&logged_asset,1,0)==0) log_line("Asset initialization failed; see the preceding log entry.");
        return;
    }
    GLint viewport[4]={0,0,0,0},old_matrix_mode=GL_MODELVIEW;
    glGetIntegerv(GL_VIEWPORT,viewport);
    glGetIntegerv(GL_MATRIX_MODE,&old_matrix_mode);
    if(viewport[2]<160||viewport[3]<160) return;

    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();
    glOrtho(viewport[0],viewport[0]+viewport[2],viewport[1],viewport[1]+viewport[3],-10.0,10.0);
    glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();

    glDisable(GL_DEPTH_TEST);glDepthMask(GL_FALSE);
    glDisable(GL_LIGHTING);glDisable(GL_CULL_FACE);
    glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_ALPHA_TEST);glAlphaFunc(GL_GREATER,0.02f);
    glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,standee_texture);
    glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
    glColor4f(1,1,1,1);

    const float scale=1.83f;
    const float cx=(float)(viewport[0]+viewport[2]-102);
    const float base=(float)(viewport[1]+32);
    DWORD now=GetTickCount();
    DWORD until=(DWORD)InterlockedCompareExchange(&greet_until,0,0);
    int greeting=(until!=0 && (int32_t)(until-now)>0);
    float wobble=0.0f,bob=0.0f;
    if(greeting) {
        float t=(float)(now-(until-1800u))*0.018f;
        wobble=(float)sin(t)*11.0f;
        bob=(float)(1.0-cos(t*2.0))*4.0f;
    }
    glTranslatef(cx,base+bob,0);
    glRotatef(wobble,0,0,1);
    glScalef(scale,scale,1);
    glBegin(GL_TRIANGLES);
    for(size_t i=0;i<mesh_count;i++) {
        glTexCoord2f(mesh[i].uv.u,mesh[i].uv.v);
        glVertex3f(mesh[i].p.x,mesh[i].p.y,mesh[i].p.z);
    }
    glEnd();
    glLoadIdentity();
    if(greeting) draw_greeting_bubble(cx,base+bob);

    glMatrixMode(GL_MODELVIEW);glPopMatrix();
    glMatrixMode(GL_PROJECTION);glPopMatrix();
    glMatrixMode(old_matrix_mode);
    glPopAttrib();
}

static BOOL WINAPI swap_buffers_hook(HDC dc) {
    static volatile LONG active_logged=0;
    static volatile LONG no_context_count=0;
    HGLRC context=wglGetCurrentContext();
    if(context) {
        if(InterlockedCompareExchange(&active_logged,1,0)==0) log_line("SwapBuffers hook reached with an active WGL context");
    } else {
        LONG count=InterlockedIncrement(&no_context_count);
        if(count==1 || count==100) log_line(count==1?"SwapBuffers hook reached without a current WGL context":"100 SwapBuffers calls observed without a current WGL context");
    }
    draw_obj_overlay();
    return original_swap_buffers(dc);
}

static DWORD WINAPI input_thread(void *unused) {
    (void)unused;
    int prev7=0,prev10=0;
    while(!InterlockedCompareExchange(&stop_worker,0,0)) {
        DWORD pid=0;GetWindowThreadProcessId(GetForegroundWindow(),&pid);
        int focused=(pid==GetCurrentProcessId());
        int k7=focused && ((GetAsyncKeyState(VK_F7)&0x8000)!=0);
        int k10=focused && ((GetAsyncKeyState(VK_F10)&0x8000)!=0);
        if(k7&&!prev7) {
            LONG before=InterlockedCompareExchange(&standee_visible,0,0);
            InterlockedExchange(&standee_visible,!before);
            log_line(before?"F7: custom textured OBJ hidden":"F7: custom textured OBJ visible");
        }
        if(k10&&!prev10) {
            InterlockedExchange(&greet_until,(LONG)(GetTickCount()+1800u));
            log_line("F10: mod-only greeting interaction; standee wobbles and says HI");
        }
        prev7=k7;prev10=k10;Sleep(20);
    }
    return 0;
}

__declspec(dllexport) int __cdecl InstallHooks(void) {
    HMODULE engine=GetModuleHandleA("animEngineDLL.dll");
    HMODULE gdi=GetModuleHandleA("gdi32.dll");
    if(!engine||!gdi) { log_line("Original engine or GDI32 is not loaded; refusing to hook.");return 0; }
    engine_base=(unsigned char *)engine;
    uintptr_t *iat=(uintptr_t *)(engine_base+SWAPBUFFERS_IAT_RVA);
    union SwapPointerBits { SwapBuffersFn function; uintptr_t bits; } system_swap,hook_swap;
    system_swap.function=(SwapBuffersFn)GetProcAddress(gdi,"SwapBuffers");
    _Static_assert(sizeof(SwapBuffersFn)==sizeof(uintptr_t),"x86 function pointer must fit one IAT entry");
    if(!system_swap.function || *iat!=system_swap.bits) {
        log_line("Original 1.1b SwapBuffers IAT pointer did not match; refusing to hook.");return 0;
    }
    original_swap_buffers=system_swap.function;
    hook_swap.function=swap_buffers_hook;
    DWORD old_protect=0;
    if(!VirtualProtect((void *)iat,sizeof(uintptr_t),PAGE_READWRITE,&old_protect)) { log_line("Could not make original engine IAT writable.");return 0; }
    *iat=hook_swap.bits;
    FlushInstructionCache(GetCurrentProcess(),(void *)iat,sizeof(uintptr_t));
    DWORD ignored=0;VirtualProtect((void *)iat,sizeof(uintptr_t),old_protect,&ignored);
    log_line("Installed version-checked GDI32 SwapBuffers IAT hook. Texture upload/render runs on the active OpenGL context before presentation.");
    input_worker=CreateThread(NULL,0,input_thread,NULL,0,NULL);
    return input_worker!=NULL;
}

BOOL WINAPI DllMain(HINSTANCE h,DWORD reason,void *reserved) {
    (void)reserved;
    if(reason==DLL_PROCESS_ATTACH) DisableThreadLibraryCalls(h);
    if(reason==DLL_PROCESS_DETACH) InterlockedExchange(&stop_worker,1);
    return TRUE;
}
