param([Parameter(Mandatory=$true)][string]$GameRoot)
$ErrorActionPreference = 'Stop'
$GameRoot = (Resolve-Path -LiteralPath $GameRoot).Path
$engine = Join-Path $GameRoot 'util\sources\facade'
if (!(Test-Path -LiteralPath (Join-Path $engine 'animEngineDLL.dll'))) {
    throw 'GameRoot must be the installed Facade directory containing util\sources\facade\animEngineDLL.dll.'
}
$expected = '815337c6f7fe05da8a99b5f261a182142907cae6f21b915b03fe6a8c1581016c'
if ((Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $engine 'animEngineDLL.dll')).Hash.ToLowerInvariant() -ne $expected) {
    throw 'Unsupported engine. Use the ORIGINAL 1.1b installation. No files were installed.'
}
if (Get-Process -Name 'facade-room-lab','Facade','facade-obj-test','trip-twins-test','facade-interactable-test' -ErrorAction SilentlyContinue) {
    throw 'Close all Facade game/mod processes before installing.'
}
$source = Join-Path $PSScriptRoot 'install'
if (!(Test-Path -LiteralPath (Join-Path $source 'util\classes\mod\Main.class'))) {
    throw 'Incomplete extracted package: missing install\util\classes\mod\Main.class.'
}
# Only mod-owned file names are installed. No original engine or stock class is replaced.
# Back up earlier copies of our own files; do not remove unrelated files from mod/.
$backup = Join-Path $GameRoot ('RoomLab-backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
foreach ($item in Get-ChildItem -LiteralPath $source -File -Recurse) {
    $relative = $item.FullName.Substring($source.Length + 1)
    $target = Join-Path $GameRoot $relative
    if (Test-Path -LiteralPath $target) {
        $saved = Join-Path $backup $relative
        New-Item -ItemType Directory -Path (Split-Path $saved) -Force | Out-Null
        Copy-Item -LiteralPath $target -Destination $saved -Force
    }
    New-Item -ItemType Directory -Path (Split-Path $target) -Force | Out-Null
    Copy-Item -LiteralPath $item.FullName -Destination $target -Force
}
Write-Host 'Installed Room Lab. Original game files are unchanged.'
Write-Host ('Run: ' + (Join-Path $engine 'facade-room-lab.exe'))
Write-Host 'Do not also inject the old Trip/vase/OBJ DLLs.'
