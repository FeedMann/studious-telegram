# Façade Room Lab

An experimental mod for the **original Windows x86 Façade 1.1b game**: an original 3D sofa, a lathed clickable vase, two wall prints, and an additive Java activation bridge. Includes a coordinated render-only Trip twin toggle.

**Not included:** the original game, original engine DLL, original textures/audio, or the original Java runtime/classes. Install the game yourself. Only the exact supported original engine is accepted; see `TECHNICAL.md` for its SHA-256 and implementation details.

## Windows install — recommended new experiment

Extract the complete package first. `GameRoot` means the game installation directory **containing `util`**, not the `util/sources/facade` engine directory.

Either copy the **contents** of this package's `install` folder into that game root, preserving all folders, or use PowerShell from the extracted Room Lab directory:

```powershell
.\Install-RoomLab.ps1 -GameRoot 'C:\Games\Facade'
```

If the shell blocks downloaded scripts, use the manual copy method, or review the script and unblock that particular script using your normal Windows policy. Administrator rights are only needed if your game directory is protected; a writable installation such as `C:\Games\Facade` is simpler. The helper scripts are provided for convenience; the actual runtime tests used Wine and a manual file copy, not native Windows/PowerShell.

After installation:

```text
Facade/
  util/classes/mod/
    Main.class
    ActivationBridge.class
    RoomLabActivationWME.class
  util/sources/facade/
    animEngineDLL.dll          <- your ORIGINAL game file, not in this package
    facade-room-lab.exe        <- run THIS
    FacadeRoomLab.dll
    room_lab/                 <- all supplied OBJ/MTL/TGA files + scene.ini
```

Close other Façade/mod sessions, then run **`util\sources\facade\facade-room-lab.exe`**. Do not run just the DLL, and do not launch the ordinary game EXE expecting these hooks. The mod launcher sets its own working directory. It starts the original engine and original Java backend through the additive wrapper. The original engine/classes on disk are not replaced.

Wait for startup. Choose a name and press Enter. Under the tested Wine/Xvfb setup, focus the Façade window; if the title/menu transition stays black, press Escape to expose the name menu, then press Enter on a selected name. Startup can take a while on software OpenGL. A single black transition screenshot is not a crash diagnosis.

### Controls

| Input | Effect |
|---|---|
| Left-click the visible 3D vase | Triangle/depth-tested activation; local wobble, then a real custom Java WME + JNI gaze request |
| F5 | Alternate staged view, 45 world units to the side; only changes camera when F6 is on |
| F6 | Optional demo staging: camera inside room, Trip pose pinned, Grace render hidden; labelled in HUD |
| F7 | Hide/show added sofa and vase |
| F8 | Hide/show the render-only Trip twin (one AI, not two) |
| F9 | Hide/show the two wall posters |

The default is **live camera**, props/posters ON, staging/twin OFF. Normal game controls still apply. F6 makes a convenient test view but is not ordinary gameplay. Java continues running in that view.

The HUD says **JAVA ACK** only after the original Java backend confirms custom WME insertion and the native gaze call returns. This does not prove a new story beat, pickup, or sustained gaze: stock behaviors may override attention. Furniture has no added collision. For complete boundaries, read `TECHNICAL.md`.

## Troubleshooting

- **Unsupported engine:** use the original supported 1.1b DLL; do not bypass the hash guard or use the incomplete decompiled engine as a substitute.
- **Missing Java wrapper:** copy all three `mod/*.class` files to `util/classes/mod`, not next to the EXE.
- **Props missing:** copy the whole `room_lab` folder next to the EXE. Read `room-lab.log`; OBJ/MTL/TGA must retain their names/relative paths. Props are in the apartment, not the starting hallway; use normal play or the explicitly staged F6 view.
- **No Java ACK:** read `room_lab/java-bridge.log` and confirm the original Java backend finishes loading. A local wobble alone is not Java proof.
- **Another mod installed:** close that session and use only one experiment's launcher. Do not stack the old DrawSprite/SwapBuffers injectors. Room Lab coordinates its own hooks.

Logs are beside the engine: `room-lab-launch.log`, `room-lab.log`, and `room_lab/java-bridge.log`. The tiny `event.txt`/`ack.txt` files are mod-owned local IPC, not game save data. The launcher clears stale event/ack data for each run.

## Linux/Wine (tested environment)

Use a complete original installed game, including its bundled Java and correctly located/decoded audio. With a 32-bit Wine prefix and an X display:

```sh
cd '/path/to/Facade/util/sources/facade'
export WINEARCH=win32 WINEPREFIX="$HOME/.wine-facade"
# Optional software rendering used for our Xvfb evidence:
export LIBGL_ALWAYS_SOFTWARE=1 LP_NUM_THREADS=2
wine facade-room-lab.exe
```

Our fresh evidence used Xvfb `:99`, Openbox, Wine32, Mesa software OpenGL, PulseAudio capture, and FFmpeg. This is not a guarantee for arbitrary Wine/GStreamer/codec installations; preserve the full original game installation rather than copying only the DLL.

## Edit / uninstall / rebuild

Edit `room_lab/scene.ini` to move/scale the supplied world meshes; restart to reload. The vase target sent to Java uses the same transform. Replace meshes only within the documented OBJ/TGA subset.

To uninstall, close the game and run:

```powershell
.\Uninstall-RoomLab.ps1 -GameRoot 'C:\Games\Facade'
```

Or remove only the added EXE, DLL, three named `mod` classes, `room_lab` assets/IPC/logs and Room Lab logs. Do not delete stock classes or the original engine. If another mod already owns `util/classes/mod`, use the reviewed install helper's backups rather than blindly copying over it. The installer backs up earlier files of the same mod-owned names; restore those manually if reverting a prior mod version. The uninstall helper checks payload hashes against the extracted package, warns and preserves modified/replaced files, and never recursively deletes unrelated files.

Rebuild instructions and architecture are in `TECHNICAL.md`. This is a Wine-tested prototype, **not** a fully autonomous extra actor or a finished engine-native object/behavior framework.
