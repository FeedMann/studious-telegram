# Room Lab: implementation and boundaries

This is an additive Windows x86 experiment for the **original Façade 1.1b engine**, not a completed decompiled engine. It contains original procedural demonstration art. It is not a release of the original game.

## Rendering

- `src/launcher.c` calculates the complete SHA-256 of `animEngineDLL.dll` **before loading it**. Only `815337c6f7fe05da8a99b5f261a182142907cae6f21b915b03fe6a8c1581016c` is accepted.
- The launcher uniquely locates the original Java entry-point string and changes `facade.Main` to `mod.Main` **in process memory only**. The original DLL on disk and original Java classes are unchanged. The wrapper immediately starts the original `facade.Main` after starting a daemon bridge.
- Checked native entry points: DrawSprite RVA `0x8c6a0`, original CPU point projector `0x8fee0`, GDI SwapBuffers IAT `0x9be790`. Instruction signatures and the original import pointer are also checked. Do not bypass guards on another build.
- Mod meshes are rendered once per native frame, through the **original CPU room projector**, with native camera/yaw, the native viewport, `glOrtho(-100,100,-100,100,0,2000)`, `GL_LESS`, and depth writes. The native scene shares this depth buffer. The additional props therefore have parallax and can be occluded. This is materially different from the upstream screen-space overlay.
- These are **mod-owned world meshes**, not registered native Sprite objects. There is no new collision, navigation obstruction, stock hand cursor, stock pickup, furniture affordance, or automatic ABL understanding of the mesh.
- The loader accepts a deliberately narrow OBJ subset: positive position/UV indices, triangulated convex polygon fans, one referenced material/texture, and uncompressed 32-bit true-colour TGA. It bounds allocations/indices, validates finite coordinates and relative asset paths, and rejects unsupported input. It is not a full OBJ implementation. Triangles crossing the near plane are conservatively skipped rather than clipped.

## The real activation path

1. The input worker queues a left-button edge only while this game process is foreground.
2. The render thread checks the actual projected vase triangles, then samples the **final scene depth** at the mouse position. A small depth tolerance accommodates the original renderer's offsets/rasterization. Hidden props and off-triangle clicks do not activate the vase. A 750 ms cooldown prevents repeated triggers.
3. The DLL publishes a scoped event by atomic rename: `sequence 1001 x y z`. The world target is the vase centre, read from the same configured transform. The vase also wobbles locally.
4. The additive Java 1.4 daemon gets the real `facade.characters.trip.java.Trip` entity, adds a custom `mod.RoomLabActivationWME` to its real working memory, then verifies `lookupWME("RoomLabActivationWME").contains(wme)`.
5. It calls the game's existing JNI command `NativeAnimationInterface.setGazeTracking(1,-1,x,y,z,1,7,0)` and writes `sequence 1 1` only after WME verification and JNI return.
6. The native HUD displays **JAVA ACK** only after receiving that acknowledgement. `room_lab/java-bridge.log` separately records the entity class, object/actor, world position, WME verification and JNI return.

The native activation sensor packet has **49 slots**. We do not resize or index past it. **1001 is a custom mod ID, not a stock activation ID.** This is a real Java-memory/native-command integration, not stock pickup or a new story beat. The stock ABL story continues to run and may immediately supersede our gaze request; an ACK is not proof of sustained attention or autonomous understanding.

To add persistent story consequences, define ABL/Jess behaviors that consume this custom WME, arbitrate gaze against the stock behaviors, and deliberately add or replace corresponding behavior registrations. Adding an ordinary custom WME does **not** make existing stock behaviors react to it. The public Java decompilation is not a clean whole-project rebuild; this package instead compiles three additive classes against the installed original classes and Java 1.4 runtime.

## Layout and controls

Default transforms in `room_lab/scene.ini` are room coordinates; restart after editing:

| Asset | Position | Purpose |
|---|---|---|
| Vase | `(170,32,-210)` | On the stock side table; native table mesh top is Y=32 |
| Teal sofa | `(-50,0,-285)` | Mod-owned furniture demonstration on the floor |
| Night poster | `(198.5,112,-220)` | Flat textured mesh just inside right wall |
| Orbit poster | `(198.5,112,-285)` | Second deterministic procedural print |

F5 changes the optional staged view by 45 world units in X. F6 enables/disables staging (camera height 80, original Trip pose pinned, Grace render hidden). **Staging is not normal gameplay and is explicitly labelled on screen.** It does not pause Java. F7 toggles sofa/vase. F8 toggles an optional second rendering of the same Trip body/head. F9 toggles wall posters. Props/posters start ON, staging and twin OFF.

The twin still has **one AI entity**. It is neither a separately simulated Trip nor a new character.

## Rebuild

On Debian with MinGW x86, Java, ECJ 3.16 (`libecj-java`), and Python Pillow:

```sh
python3 generate_assets.py
bash build.sh /absolute/path/to/installed/Facade
```

The native build uses `-Wall -Wextra -Werror`. ECJ uses the original bundled `rt.jar` and installed game classes, `-1.4 -target 1.4`; class-file major version is 48. A bare modern `javac` cannot produce the required Java 1.4 bytecode. `generate_assets.py` expects DejaVu Sans under Debian's standard font path; the shipped assets do not need regenerating.

## Security/support

Use only a trusted local game installation and these mod-owned files. This package is a prototype tested under Wine/Xvfb, not a generally supported Windows release. It has not been tested with arbitrary engines, native modern Windows, resolution changes, every room/camera angle, long sessions, every OBJ exporter, or other injectors. The single-file mailbox is intentionally a local, latest-event prototype, not a multiplayer/network or durable transaction protocol. Close the game before changing DLLs/classes or uninstalling.
