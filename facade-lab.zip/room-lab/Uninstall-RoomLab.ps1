param([Parameter(Mandatory=$true)][string]$GameRoot)
$ErrorActionPreference = 'Stop'
$GameRoot = (Resolve-Path -LiteralPath $GameRoot).Path
$engine = Join-Path $GameRoot 'util\sources\facade'
if (!(Test-Path -LiteralPath (Join-Path $engine 'animEngineDLL.dll'))) { throw 'Not an installed Facade root.' }
if (Get-Process -Name 'facade-room-lab' -ErrorAction SilentlyContinue) { throw 'Close Room Lab first.' }
# Never delete a directory recursively: preserve unrelated user/mod files.
$files = @('util\sources\facade\facade-room-lab.exe','util\sources\facade\FacadeRoomLab.dll',
'util\classes\mod\Main.class','util\classes\mod\ActivationBridge.class','util\classes\mod\RoomLabActivationWME.class',
'util\sources\facade\room-lab.log','util\sources\facade\room-lab-launch.log')
$assetNames = @('table_vase.obj','table_vase.mtl','lounge_sofa.obj','lounge_sofa.mtl','night_print.obj','night_print.mtl',
'night_print.tga','orbit_print.obj','orbit_print.mtl','orbit_print.tga','palette.tga','scene.ini',
'event.txt','event.tmp','ack.txt','ack.tmp','java-bridge.log')
foreach ($name in $assetNames) { $files += 'util\sources\facade\room_lab\' + $name }
foreach ($relative in $files) {
    $path = Join-Path $GameRoot $relative
    if (Test-Path -LiteralPath $path -PathType Leaf) {
        $reference = Join-Path (Join-Path $PSScriptRoot 'install') $relative
        if (Test-Path -LiteralPath $reference -PathType Leaf) {
            if ((Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash -ne (Get-FileHash -Algorithm SHA256 -LiteralPath $reference).Hash) {
                Write-Warning ('Preserving modified/replaced file: ' + $path)
                continue
            }
        } elseif ($relative -notmatch '(room-lab(-launch)?\.log|room_lab\\(event\.(txt|tmp)|ack\.(txt|tmp)|java-bridge\.log))$') {
            Write-Warning ('No package reference; preserving: ' + $path)
            continue
        }
        Remove-Item -LiteralPath $path
    }
}
foreach ($relative in @('util\classes\mod','util\sources\facade\room_lab')) {
    $path = Join-Path $GameRoot $relative
    if ((Test-Path -LiteralPath $path) -and !(Get-ChildItem -LiteralPath $path -Force)) { Remove-Item -LiteralPath $path }
}
Write-Host 'Removed Room Lab files only. Original engine, original classes, backups and other mods preserved.'
