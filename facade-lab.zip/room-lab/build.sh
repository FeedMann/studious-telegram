#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
CC="${CC:-i686-w64-mingw32-gcc}"
GAME_ROOT="${1:-${FACADE_GAME_ROOT:-}}"
mkdir -p bin java_classes
"$CC" -std=c11 -O2 -Wall -Wextra -Werror -Wno-misleading-indentation -shared -o bin/FacadeRoomLab.dll src/room_lab.c -lopengl32 -lgdi32 -luser32 -lm -static-libgcc
"$CC" -std=c11 -O2 -Wall -Wextra -Werror -Wno-misleading-indentation -mwindows -o bin/facade-room-lab.exe src/launcher.c -ladvapi32 -luser32 -static-libgcc
if [[ -n "$GAME_ROOT" ]]; then
  ECJ="${ECJ_JAR:-/usr/share/java/ecj.jar}"
  java -cp "$ECJ" org.eclipse.jdt.internal.compiler.batch.Main -1.4 -target 1.4 -bootclasspath "$GAME_ROOT/util/j2re1.4.2_06/lib/rt.jar" -classpath "$GAME_ROOT/util/classes" -d java_classes java/mod/*.java
else
  echo 'Native binaries built. Pass the installed game root to also compile additive Java 1.4 classes.'
fi
