#!/usr/bin/env python3
"""Original procedural demonstration assets. No original-game art is copied."""
from pathlib import Path
import math, random, shutil
from PIL import Image, ImageDraw, ImageFont
ROOT=Path(__file__).resolve().parent
ASSETS=ROOT/'assets'/'room_lab';ASSETS.mkdir(parents=True,exist_ok=True)
class Mesh:
    def __init__(self,name): self.name=name;self.v=[];self.uv=[];self.faces=[]
    def face(self,points,uv=None):
        start=len(self.v)+1; t=len(self.uv)+1
        self.v.extend(points)
        self.uv.extend(uv or [(0.5,0.5)]*len(points))
        self.faces.append('f '+' '.join('%d/%d'%(start+i,t+i) for i in range(len(points))))
    def box(self,lo,hi,colors=(0,1,2,3,4,5)):
        x,y,z=lo;X,Y,Z=hi
        p=[(x,y,z),(X,y,z),(X,Y,z),(x,Y,z),(x,y,Z),(X,y,Z),(X,Y,Z),(x,Y,Z)]
        for face,c in zip([(0,3,2,1),(4,5,6,7),(0,4,7,3),(1,2,6,5),(3,7,6,2),(0,1,5,4)],colors):
            u=((c%8)+0.5)/8;v=((c//8)+0.5)/8
            self.face([p[i] for i in face],[(u,v)]*4)
    def save(self,texture='palette.tga'):
        text=['# Original procedural mesh for Façade Room Lab','mtllib '+self.name+'.mtl','o '+self.name]
        text+=['v %.5f %.5f %.5f'%p for p in self.v]
        text+=['vt %.6f %.6f'%uv for uv in self.uv]
        text+=['usemtl RoomLab']+self.faces
        (ASSETS/(self.name+'.obj')).write_text('\n'.join(text)+'\n')
        (ASSETS/(self.name+'.mtl')).write_text('newmtl RoomLab\nKd 1 1 1\nmap_Kd '+texture+'\n')
# Small opaque atlas, uncompressed 32-bit TGA (same subset as the upstream demo).
colors=['#193d4b','#24556a','#32778a','#3c8d98','#51a8ad','#12313e','#bf683f','#e5ac63',
        '#654338','#9e6446','#cd8051','#ecb078','#e7c6a0','#422e2c','#d78c47','#ffd594',
        '#141f2b','#33455e','#536c81','#87a4b2','#d4ded6','#e3cd81','#a44141','#f3eee2']
palette=Image.new('RGBA',(128,128),(255,255,255,255));d=ImageDraw.Draw(palette)
for c in range(64):
    # TGA saved top-origin by Pillow; loader handles orientation.
    col=colors[c%len(colors)]; x=(c%8)*16; y=128-(c//8+1)*16
    d.rectangle((x,y,x+15,y+15),fill=col)
palette.save(ASSETS/'palette.tga',compression=None)
sofa=Mesh('lounge_sofa')
sofa.box((-45,6,-19),(45,16,19))
sofa.box((-45,15,-19),(45,44,-11),(0,1,0,1,2,0))
sofa.box((-45,13,-13),(-36,31,19),(0,1,0,1,3,0))
sofa.box((36,13,-13),(45,31,19),(0,1,0,1,3,0))
for lo,hi in [((-35,16,-10),(-1,23,18)),((1,16,-10),(35,23,18))]:sofa.box(lo,hi,(1,2,1,2,4,1))
for x in [-37,32]:
    for z in [-13,11]:sofa.box((x,0,z),(x+5,7,z+5),(5,5,5,5,6,5))
sofa.save()
vase=Mesh('table_vase');rings=[(0,6),(2,8),(7,9),(15,10),(22,7),(26,4),(30,4),(32,6)]
for j in range(len(rings)-1):
    y,r=rings[j];Y,R=rings[j+1]
    for s in range(12):
        a=s*2*math.pi/12;b=(s+1)*2*math.pi/12
        c=8+(s%5);uv=((c%8+.5)/8,(c//8+.5)/8)
        vase.face([(r*math.cos(a),y,r*math.sin(a)),(r*math.cos(b),y,r*math.sin(b)),(R*math.cos(b),Y,R*math.sin(b)),(R*math.cos(a),Y,R*math.sin(a))],[uv]*4)
# Dark mouth and a rim.
for s in range(12):
    a=s*2*math.pi/12;b=(s+1)*2*math.pi/12
    vase.face([(0,31.7,0),(5.5*math.cos(a),31.7,5.5*math.sin(a)),(5.5*math.cos(b),31.7,5.5*math.sin(b))],[(.6875,.1875)]*3)
vase.save()
# Two flat OBJ planes on the right wall; normal points into the apartment.
for name in ['night_print','orbit_print']:
    mesh=Mesh(name)
    mesh.face([(0,-22,-15),(0,-22,15),(0,22,15),(0,22,-15)],[(0,0),(1,0),(1,1),(0,1)])
    mesh.save(name+'.tga')
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
def f(size): return ImageFont.truetype(font,size)
for i,name in enumerate(['night_print','orbit_print']):
    rng=random.Random(20261014+i); im=Image.new('RGBA',(256,384),'#e7e4d7');dr=ImageDraw.Draw(im)
    dr.rectangle((13,13,242,370),fill=['#123444','#22263e'][i])
    if i==0:
        dr.ellipse((95,50,202,157),fill='#e7ab62')
        for j in range(13):
            x=20+j*18;h=rng.randrange(70,170)
            dr.rectangle((x,280-h,x+13,280),fill=['#326b7a','#438c93','#265366'][j%3])
        dr.text((28,305),'NIGHT / 05',font=f(24),fill='#f3ebd9')
        dr.text((29,338),'ROOM LAB EDITION',font=f(13),fill='#d6ad77')
    else:
        for j in range(4):
            r=25+j*22;dr.ellipse((128-r,174-r,128+r,174+r),outline='#ecb174',width=3)
        dr.ellipse((108,154,148,194),fill='#eaa969')
        dr.ellipse((177,118,196,137),fill='#71aaa9')
        for j in range(35):
            x=rng.randrange(24,232);y=rng.randrange(35,280);dr.ellipse((x,y,x+2,y+2),fill='#e7e4d7')
        dr.text((34,305),'ORBIT / 02',font=f(24),fill='#f3ebd9')
        dr.text((30,338),'A SMALL WALL EXPERIMENT',font=f(11),fill='#d6ad77')
    im.save(ASSETS/(name+'.tga'),compression=None)
# Exact transforms are configurable and shared with the Java activation event.
(ASSETS/'scene.ini').write_text('''; World coordinates, not screen positions. Restart after editing.
[vase]
x=170
y=32
z=-210
scale=1
[sofa]
x=-50
y=0
z=-285
scale=1
[poster1]
x=198.5
y=112
z=-220
scale=1
[poster2]
x=198.5
y=112
z=-285
scale=1
''')
print('Created sofa, lathed vase, two wall prints and scene.ini in',ASSETS)
# Repair the upstream OBJ demo packaging with an explicit new test asset.
repair=ROOT.parent/'obj-repaired'/'obj_demo';repair.mkdir(parents=True,exist_ok=True)
# The upstream C source hardcodes TetoStandee.obj. This test file is a sofa, not Teto art.
text=(ASSETS/'lounge_sofa.obj').read_text().replace('lounge_sofa.mtl','TetoStandee.mtl')
# Upstream overlay glOrtho clips Z outside [-10,10], unlike the room renderer.
# Compress ONLY this compatibility test asset's Z; do not change upstream code.
lines=[]
for line in text.splitlines():
    if line.startswith('v '):
        xyz=list(map(float,line.split()[1:]));xyz[2]*=.1
        line='v %.5f %.5f %.5f'%tuple(xyz)
    lines.append(line)
(repair/'TetoStandee.obj').write_text('\n'.join(lines)+'\n')
(repair/'TetoStandee.mtl').write_text('newmtl RoomLab\nKd 1 1 1\nmap_Kd palette.tga\n')
shutil.copy2(ASSETS/'palette.tga',repair/'palette.tga')
