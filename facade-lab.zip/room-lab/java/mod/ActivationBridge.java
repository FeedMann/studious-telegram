package mod;
import java.io.*;
import java.util.StringTokenizer;
import abl.runtime.BehavingEntity;
import facade.nativeinterface.NativeAnimationInterface;
/** Java 1.4-compatible side channel. Does not resize/touch the stock 49-entry packet. */
public final class ActivationBridge extends Thread {
    private long lastSequence;
    private long lastError;
    private RoomLabActivationWME previous;
    public ActivationBridge() { super("RoomLabActivationBridge"); }
    private static synchronized void log(String message) {
        try {
            PrintWriter out=new PrintWriter(new FileWriter("room_lab/java-bridge.log",true));
            out.println(System.currentTimeMillis()+": "+message);out.close();
        } catch(IOException ignored) { }
    }
    private static void ack(long sequence) throws IOException {
        File temporary=new File("room_lab/ack.tmp"),target=new File("room_lab/ack.txt");
        PrintWriter out=new PrintWriter(new FileWriter(temporary));
        out.println(sequence+" 1 1");out.close();
        if(target.exists()&&!target.delete())throw new IOException("Cannot replace ack.txt");
        if(!temporary.renameTo(target))throw new IOException("Cannot publish ack.txt");
    }
    private void poll() throws Exception {
        File event=new File("room_lab/event.txt");if(!event.isFile())return;
        BufferedReader input=new BufferedReader(new FileReader(event));String line;
        try {line=input.readLine();}finally{input.close();}
        if(line==null||line.length()>200)return;
        StringTokenizer fields=new StringTokenizer(line);if(fields.countTokens()!=5)return;
        long seq=Long.parseLong(fields.nextToken());int object=Integer.parseInt(fields.nextToken());
        float x=Float.parseFloat(fields.nextToken()),y=Float.parseFloat(fields.nextToken()),z=Float.parseFloat(fields.nextToken());
        if(seq<=lastSequence||seq<1||object!=1001||Float.isNaN(x)||Float.isNaN(y)||Float.isNaN(z)||Math.abs(x)>10000||Math.abs(y)>10000||Math.abs(z)>10000)return;
        BehavingEntity trip=BehavingEntity.getBehavingEntity("Trip");if(trip==null)return;
        if(previous!=null)trip.deleteWME(previous);
        RoomLabActivationWME wme=new RoomLabActivationWME(seq,object,2,x,y,z);
        trip.addWME(wme);
        boolean inserted=trip.lookupWME("RoomLabActivationWME").contains(wme);
        if(!inserted)throw new IllegalStateException("WME lookup did not confirm insertion");
        previous=wme;
        log("WME VERIFIED seq="+seq+" entity="+trip.getClass().getName()+" class=mod.RoomLabActivationWME object="+object+" actor=2 world="+x+","+y+","+z);
        // Original native command API: medium, head-and-eyes-only, no head cock.
        // Stock ABL still runs and can issue a later command which supersedes this.
        NativeAnimationInterface.setGazeTracking(1,-1,x,y,z,1,7,0);
        log("JNI RETURNED seq="+seq+" setGazeTracking(Trip=1, explicit-world-target, speed=1, type=7, cock=0); request, not proof of sustained visible gaze");
        NativeAnimationInterface.addEventInfoToLog("RoomLab custom activation #"+seq+" (not stock pickup)");
        ack(seq);lastSequence=seq;
    }
    public void run() {
        log("START additive wrapper; Java "+System.getProperty("java.version")+"; stock facade.Main will run; no original class replaced");
        while(true) {
            try { poll(); } catch(Throwable error) {
                long now=System.currentTimeMillis();if(now-lastError>3000){log("BRIDGE ERROR "+error.toString());lastError=now;}
            }
            try {Thread.sleep(60);}catch(InterruptedException stop){return;}
        }
    }
}
