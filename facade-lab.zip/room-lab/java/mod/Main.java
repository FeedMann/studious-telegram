package mod;
/** Additive entry point; the original facade.Main and every stock class remain intact. */
public final class Main {
    public static void main(String[] args) {
        ActivationBridge bridge = new ActivationBridge();
        bridge.setDaemon(true);
        bridge.start();
        facade.Main.main(args);
    }
}
