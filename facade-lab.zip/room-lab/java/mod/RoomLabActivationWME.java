package mod;
import wm.WME;
/** A MOD-SPECIFIC WME. Not the stock ObjectActivationWME or a new native object ID. */
public final class RoomLabActivationWME extends WME {
    private long sequence;
    private int objectID;
    private int activatorID;
    private float x, y, z;
    public RoomLabActivationWME(long s, int object, int actor, float a, float b, float c) {
        sequence=s;objectID=object;activatorID=actor;x=a;y=b;z=c;
    }
    public synchronized long getSequence() { return sequence; }
    public synchronized int getObjectID() { return objectID; }
    public synchronized int getActivatorID() { return activatorID; }
    public synchronized float getX() { return x; }
    public synchronized float getY() { return y; }
    public synchronized float getZ() { return z; }
}
