/* Small validated OBJ/MTL/TGA subset. GL upload is render-thread only. */
#ifndef ROOMLAB_ASSETS_H
#define ROOMLAB_ASSETS_H
#include <ctype.h>
#include <limits.h>
#define MAX_VERTS 8192
#define MAX_INPUT_VERTS 4096
struct Vec3 {float x,y,z;};
struct UV {float u,v;};
struct Vertex {struct Vec3 p;struct UV uv;};
struct Asset {const char *path;struct Vertex vertices[MAX_VERTS];size_t count;GLuint texture;struct Vec3 at;float scale;int ok;};
static int finite3(struct Vec3 v){return isfinite(v.x)&&isfinite(v.y)&&isfinite(v.z)&&fabsf(v.x)<100000&&fabsf(v.y)<100000&&fabsf(v.z)<100000;}
static int adjacent_path(char *dst,size_t cap,const char *src,const char *name){
    /* Asset files intentionally stay in their own directory. */
    if(!name[0]||strstr(name,"..")||strchr(name,'/')||strchr(name,'\\')||strchr(name,':'))return 0;
    const char *slash=strrchr(src,'/');size_t n=slash?(size_t)(slash-src+1):0;
    if(n+strlen(name)+1>cap)return 0;
    memcpy(dst,src,n);strcpy(dst+n,name);return 1;
}
static int image_tga(const char *path,GLuint *tex){
    FILE *f=fopen(path,"rb");if(!f)return 0;
    unsigned char h[18];
    if(fread(h,1,18,f)!=18||h[1]!=0||h[2]!=2||h[16]!=32){fclose(f);return 0;}
    int w=h[12]|h[13]<<8,ht=h[14]|h[15]<<8;
    if(w<1||ht<1||w>2048||ht>2048||fseek(f,h[0],SEEK_CUR)){fclose(f);return 0;}
    size_t bytes=(size_t)w*ht*4;unsigned char *raw=malloc(bytes),*rgba=malloc(bytes);
    if(!raw||!rgba||fread(raw,1,bytes,f)!=bytes){free(raw);free(rgba);fclose(f);return 0;}fclose(f);
    for(int y=0;y<ht;y++)for(int x=0;x<w;x++){
        int sx=(h[17]&16)?w-1-x:x,sy=(h[17]&32)?ht-1-y:y;
        size_t a=((size_t)sy*w+sx)*4,b=((size_t)y*w+x)*4;
        rgba[b]=raw[a+2];rgba[b+1]=raw[a+1];rgba[b+2]=raw[a];rgba[b+3]=raw[a+3];
    }
    glGenTextures(1,tex);glBindTexture(GL_TEXTURE_2D,*tex);glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,w,ht,0,GL_RGBA,GL_UNSIGNED_BYTE,rgba);
    free(raw);free(rgba);return *tex!=0;
}
static int load_asset(struct Asset *a){
    FILE *f=fopen(a->path,"rb");if(!f)return 0;
    struct Vec3 *positions=calloc(MAX_INPUT_VERTS,sizeof *positions);
    struct UV *uv=calloc(MAX_INPUT_VERTS,sizeof *uv);
    if(!positions||!uv){free(positions);free(uv);fclose(f);return 0;}
    char line[4096],material[160]="";size_t np=0,nt=0;int ok=1;a->count=0;
    while(ok&&fgets(line,sizeof line,f)){
        size_t len=strlen(line);if(len==sizeof line-1&&line[len-1]!='\n'){ok=0;break;}
        if(!strncmp(line,"v ",2)){
            struct Vec3 p;if(np==MAX_INPUT_VERTS||sscanf(line+2,"%f %f %f",&p.x,&p.y,&p.z)!=3||!finite3(p)){ok=0;break;}positions[np++]=p;
        }else if(!strncmp(line,"vt ",3)){
            struct UV t;if(nt==MAX_INPUT_VERTS||sscanf(line+3,"%f %f",&t.u,&t.v)!=2||!isfinite(t.u)||!isfinite(t.v)){ok=0;break;}uv[nt++]=t;
        }else if(!strncmp(line,"mtllib ",7)){
            if(sscanf(line+7,"%159s",material)!=1)ok=0;
        }else if(!strncmp(line,"f ",2)){
            unsigned vi[64],ti[64];int n=0;char *tok=strtok(line+2," \t\r\n");
            while(tok&&tok[0]!='#'){
                if(n==64){ok=0;break;}
                char *end=0;long v=strtol(tok,&end,10);
                if(end==tok||*end!='/'||v<1||v>(long)np){ok=0;break;}
                char *start=end+1;long t=strtol(start,&end,10);
                if(end==start||(*end&&*end!='/')||t<1||t>(long)nt){ok=0;break;}
                vi[n]=(unsigned)(v-1);ti[n]=(unsigned)(t-1);n++;tok=strtok(NULL," \t\r\n");
            }
            if(n<3){ok=0;break;}
            for(int j=1;ok&&j<n-1;j++)for(int k=0;k<3;k++){
                int q=k==0?0:(k==1?j:j+1);
                if(a->count==MAX_VERTS){ok=0;break;}
                a->vertices[a->count++]=(struct Vertex){positions[vi[q]],uv[ti[q]]};
            }
        }
    }
    if(ferror(f))ok=0;fclose(f);free(positions);free(uv);
    if(!ok||a->count<3||!material[0])return 0;
    char mtl[MAX_PATH],texture[MAX_PATH],name[160]="";
    if(!adjacent_path(mtl,sizeof mtl,a->path,material))return 0;
    f=fopen(mtl,"rb");if(!f)return 0;
    while(fgets(line,sizeof line,f))if(!strncmp(line,"map_Kd ",7)){sscanf(line+7,"%159s",name);break;}fclose(f);
    if(!adjacent_path(texture,sizeof texture,mtl,name)||!image_tga(texture,&a->texture))return 0;
    a->ok=1;return 1;
}
#endif
