/* Load the known original engine and redirect only its in-memory Java main
 * class to our additive wrapper. No original .class or engine file is edited. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wincrypt.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
static const unsigned char expected[32]={0x81,0x53,0x37,0xc6,0xf7,0xfe,0x05,0xda,0x8a,0x99,0xb5,0xf2,0x61,0xa1,0x82,0x14,0x29,0x07,0xca,0xe6,0xf2,0x1b,0x91,0x5b,0x03,0xfe,0x6a,0x8c,0x15,0x81,0x01,0x6c};
typedef int (__cdecl *EngineMain)(HINSTANCE,HINSTANCE,LPSTR,int);
typedef int (__cdecl *InstallFn)(void);
static void log_line(const char*s){FILE*f=fopen("room-lab-launch.log","a");if(f){fprintf(f,"%lu: %s\n",(unsigned long)GetTickCount(),s);fclose(f);}}
static int fail(const char *s,int code){log_line(s);MessageBoxA(NULL,s,"Façade Room Lab",MB_OK|MB_ICONERROR);return code;}
static int hash_ok(void){
    HANDLE f=CreateFileA("animEngineDLL.dll",GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(f==INVALID_HANDLE_VALUE)return 0;
    HCRYPTPROV p=0;HCRYPTHASH h=0;unsigned char buf[65536],digest[32];DWORD n=0,size=32;
    int ok=CryptAcquireContextA(&p,NULL,NULL,PROV_RSA_AES,CRYPT_VERIFYCONTEXT)&&CryptCreateHash(p,CALG_SHA_256,0,0,&h);
    while(ok){if(!ReadFile(f,buf,sizeof buf,&n,NULL)){ok=0;break;}if(!n)break;ok=CryptHashData(h,buf,n,0);}
    if(ok)ok=CryptGetHashParam(h,HP_HASHVAL,digest,&size,0)&&size==32&&!memcmp(digest,expected,32);
    if(h)CryptDestroyHash(h);if(p)CryptReleaseContext(p,0);CloseHandle(f);return ok;
}
static int redirect_java(HMODULE module){
    unsigned char*b=(unsigned char*)module;IMAGE_DOS_HEADER*dos=(IMAGE_DOS_HEADER*)b;IMAGE_NT_HEADERS32*nt=(IMAGE_NT_HEADERS32*)(b+dos->e_lfanew);
    if(dos->e_magic!=IMAGE_DOS_SIGNATURE||nt->Signature!=IMAGE_NT_SIGNATURE||nt->OptionalHeader.Magic!=IMAGE_NT_OPTIONAL_HDR32_MAGIC)return 0;
    IMAGE_SECTION_HEADER*sections=IMAGE_FIRST_SECTION(nt);unsigned char*found=NULL;unsigned count=0;
    static const char original[]="facade.Main";
    for(unsigned j=0;j<nt->FileHeader.NumberOfSections;j++){
        IMAGE_SECTION_HEADER*s=&sections[j];if(!(s->Characteristics&IMAGE_SCN_MEM_READ))continue;
        size_t n=s->Misc.VirtualSize;if(n<sizeof original)continue;
        for(size_t i=0;i+sizeof original<=n;i++)if(!memcmp(b+s->VirtualAddress+i,original,sizeof original)){found=b+s->VirtualAddress+i;count++;}
    }
    if(count!=1)return 0;DWORD old,ignored;
    if(!VirtualProtect(found,sizeof original,PAGE_READWRITE,&old))return 0;
    memset(found,0,sizeof original);memcpy(found,"mod.Main",8);VirtualProtect(found,sizeof original,old,&ignored);
    log_line("Original Java command changed in process memory only: facade.Main -> mod.Main. Wrapper calls stock Main.");return 1;
}
int WINAPI WinMain(HINSTANCE inst,HINSTANCE prev,LPSTR cmd,int show){
    char path[MAX_PATH];DWORD n=GetModuleFileNameA(NULL,path,sizeof path);if(!n||n>=sizeof path)return fail("Launcher path is too long.",1);
    char *slash=strrchr(path,'\\');if(!slash)return fail("Cannot determine game directory.",1);*slash=0;if(!SetCurrentDirectoryA(path))return fail("Cannot open the game data directory.",1);
    if(!hash_ok())return fail("Only the ORIGINAL Façade 1.1b engine is supported.\nSHA-256 must begin 815337c6f7fe05da...\n\nPlace this launcher beside animEngineDLL.dll; do not bypass the guard.",2);
    log_line("PASS exact original engine SHA-256 815337c6f7fe05da8a99b5f261a182142907cae6f21b915b03fe6a8c1581016c");
    if(GetFileAttributesA("..\\..\\classes\\mod\\Main.class")==INVALID_FILE_ATTRIBUTES)return fail("Missing additive Java wrapper: util\\classes\\mod\\Main.class. Install the complete package, not just the EXE/DLL.",3);
    if(GetFileAttributesA("room_lab\\scene.ini")==INVALID_FILE_ATTRIBUTES)return fail("Missing room_lab assets/config folder.",3);
    DeleteFileA("room_lab/event.txt");DeleteFileA("room_lab/ack.txt");DeleteFileA("room_lab/event.tmp");
    HMODULE engine=LoadLibraryA("animEngineDLL.dll");if(!engine)return fail("Original engine could not load. Check the installed game dependencies.",4);
    if(!redirect_java(engine))return fail("The expected original Java launch string was not found exactly once. No game session started.",5);
    HMODULE mod=LoadLibraryA("FacadeRoomLab.dll");InstallFn install=mod?(InstallFn)GetProcAddress(mod,"InstallHooks"):NULL;
    if(!install||!install())return fail("Checked render hooks failed. Close this process and check room-lab.log. Do not stack this DLL with TripTwins/Interactable hooks.",6);
    EngineMain start=(EngineMain)GetProcAddress(engine,"?AnimEngineWinMain@@YAHPAUHINSTANCE__@@0PADH@Z");if(!start)return fail("Original engine entry point missing.",7);
    return start(inst,prev,cmd,show);
}
