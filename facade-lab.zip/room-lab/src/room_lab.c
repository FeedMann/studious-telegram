/* Façade Room Lab, Windows x86; original 1.1b only.
 * New, mod-owned room-space OBJ meshes use the engine's actual CPU projector
 * (RVA 0x8fee0) and its existing depth buffer. They are not native Sprite IDs.
 * A file bridge enters a separate mod WME in the real Java Trip entity and
 * issues a normal JNI gaze request. No stock activation-array expansion.
 * Trip duplication derives from the supplied Trip-Twins experiment.
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <GL/gl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdarg.h>
#if !defined(__i386__)
#error Build for Windows x86 only.
#endif
#include "assets.h"
#define DRAW_RVA 0x8c6a0u
#define SWAP_RVA 0x9be790u
#define PROJECT_RVA 0x8fee0u
#define PLAYER_RVA 0x979474u
#define TRIP_RVA 0x979480u
#define FRAME_RVA 0x83f62cu

typedef void (__cdecl *DrawFn)(void*,unsigned char);
typedef BOOL (WINAPI *SwapFn)(HDC);
typedef void (__cdecl *ProjectFn)(struct Vec3,struct Vec3*,float*,int);
typedef struct Vec3* (__attribute__((thiscall)) *GetVecFn)(void*,struct Vec3*);
typedef void (__attribute__((thiscall)) *PosFn)(void*,float,float,float,float);
typedef void (__attribute__((thiscall)) *RotFn)(void*,float,float,float);
static unsigned char *engine;
static DrawFn original_draw;
static SwapFn original_swap;
static ProjectFn project_world;
static volatile LONG stop_worker,photo_mode,side_view,props_visible=1,posters_visible=1,twins_on,click_queued;
static int in_draw,initialized,assets_ok,intro_saved;
static DWORD last_draw_frame=0xffffffffu,photo_frame=0xffffffffu;
static struct Vec3 original_camera,original_rot,trip_at,trip_rot,photo_camera;
static int game_started;
static GLuint font_base;
static DWORD last_action,active_until;
static unsigned long sequence,ack_sequence;
static int hover,depth_hit;
static float pick_x0,pick_x1,pick_y0,pick_y1;
static struct Asset assets[4]={
    {.path="room_lab/table_vase.obj",.at={170,32,-210},.scale=1},
    {.path="room_lab/lounge_sofa.obj",.at={-50,0,-285},.scale=1},
    {.path="room_lab/night_print.obj",.at={198.5f,112,-220},.scale=1},
    {.path="room_lab/orbit_print.obj",.at={198.5f,112,-285},.scale=1}
};
struct ScreenVertex{float x,y,depth;int valid;};
static struct ScreenVertex hit_vertices[MAX_VERTS];
static HWND game_window;
static int client_width,client_height;
static GLint viewport[4];
static void log_line(const char *fmt,...){
    FILE *f=fopen("room-lab.log","a");if(!f)return;
    fprintf(f,"%lu: ",(unsigned long)GetTickCount());va_list a;va_start(a,fmt);vfprintf(f,fmt,a);va_end(a);fputc('\n',f);fclose(f);
}
static LONG atomic(volatile LONG *v){return InterlockedCompareExchange(v,0,0);}
static struct Vec3 vector(void *s,unsigned n){struct Vec3 v={0};uintptr_t *vt=*(uintptr_t**)s;((GetVecFn)vt[n])(s,&v);return v;}
static void pose(void *s,struct Vec3 p,struct Vec3 r){uintptr_t *v=*(uintptr_t**)s;((PosFn)v[15])(s,p.x,p.y,p.z,-1);((RotFn)v[16])(s,r.x,r.y,r.z);}
static void stage(void *sprite){
    void *player=*(void**)(engine+PLAYER_RVA),*trip=*(void**)(engine+TRIP_RVA);
    if(!player||!trip||*(int*)((char*)player+4)!=2)return;
    if(!intro_saved&&sprite==trip){
        original_camera=vector(player,11);original_rot=vector(player,12);trip_at=vector(trip,11);trip_rot=vector(trip,12);
        float yaw=original_rot.y*0.01745329252f;
        photo_camera=(struct Vec3){trip_at.x-190*sinf(yaw),80,trip_at.z+190*cosf(yaw)};
        intro_saved=1;log_line("Intro snapshot; staged camera %.2f %.2f %.2f yaw %.2f",photo_camera.x,photo_camera.y,photo_camera.z,original_rot.y);
    }
    /* Name is changed from 'player' by the stock name-choice screen. */
    if(!game_started&&strcmp((char*)player+8,"player")){
        game_started=1;log_line("Stock game name selected; room-space rendering enabled. Java is not paused.");
    }
    if(intro_saved&&atomic(&photo_mode)){
        DWORD frame=*(DWORD*)(engine+FRAME_RVA);
        if(frame!=photo_frame){
            photo_frame=frame;struct Vec3 camera=photo_camera;
            if(atomic(&side_view))camera.x+=45;
            pose(player,camera,original_rot);pose(trip,trip_at,trip_rot);
        }
    }
}
static float config_float(const char *section,const char *key,float def){
    char s[64],fallback[64];snprintf(fallback,sizeof fallback,"%.6f",def);
    GetPrivateProfileStringA(section,key,fallback,s,sizeof s,".\\room_lab\\scene.ini");
    char *end;float v=strtof(s,&end);return end!=s&&isfinite(v)&&fabsf(v)<10000?v:def;
}
static void init_assets(void){
    if(initialized)return;initialized=1;
    const char *sections[]={"vase","sofa","poster1","poster2"};assets_ok=1;
    glPushAttrib(GL_ALL_ATTRIB_BITS);
    for(unsigned i=0;i<4;i++){
        struct Asset *a=&assets[i];a->at.x=config_float(sections[i],"x",a->at.x);a->at.y=config_float(sections[i],"y",a->at.y);a->at.z=config_float(sections[i],"z",a->at.z);a->scale=config_float(sections[i],"scale",a->scale);
        if(a->scale<=0||a->scale>20||!load_asset(a)){assets_ok=0;log_line("ASSET FAIL: %s",a->path);continue;}
        log_line("OBJ loaded: %s; %lu triangle vertices; world %.2f %.2f %.2f scale %.2f",a->path,(unsigned long)a->count,a->at.x,a->at.y,a->at.z,a->scale);
    }
    glPopAttrib();
}
static int client_info(HDC dc){
    HWND w=WindowFromDC(dc);RECT r;
    if(!w||!GetClientRect(w,&r))return 0;
    game_window=w;client_width=r.right-r.left;client_height=r.bottom-r.top;
    glGetIntegerv(GL_VIEWPORT,viewport);
    return client_width>100&&client_height>100&&viewport[2]>100&&viewport[3]>100;
}
static struct Vec3 to_world(struct Asset *a,struct Vec3 p,int index){
    float angle=0;
    if(index==0&&active_until&&(LONG)(active_until-GetTickCount())>0)angle=sinf(GetTickCount()*.009f)*.14f;
    float c=cosf(angle),s=sinf(angle);
    return (struct Vec3){a->at.x+(c*p.x+s*p.z)*a->scale,a->at.y+p.y*a->scale,a->at.z+(-s*p.x+c*p.z)*a->scale};
}
static void draw_mesh(int index){
    struct Asset *a=&assets[index];if(!a->ok)return;
    struct Vec3 projected[3];int allvalid;
    glEnable(GL_TEXTURE_2D);glBindTexture(GL_TEXTURE_2D,a->texture);
    int active=index==0&&active_until&&(LONG)(active_until-GetTickCount())>0;
    glColor4f(active?1.0f:1.0f,active?1.0f:1.0f,active?.74f:1.0f,1);
    if(index==0){pick_x0=pick_y0=1e8f;pick_x1=pick_y1=-1e8f;}
    glBegin(GL_TRIANGLES);
    for(size_t t=0;t<a->count;t+=3){
        allvalid=1;
        for(int k=0;k<3;k++){
            float factor=0;struct Vec3 world=to_world(a,a->vertices[t+k].p,index);
            project_world(world,&projected[k],&factor,1);
            int valid=finite3(projected[k])&&projected[k].z<-1&&projected[k].z>-1990;
            if(!valid)allvalid=0;
            if(index==0){
                struct ScreenVertex v={(projected[k].x/100+1)*viewport[2]*.5f+viewport[0],client_height-((projected[k].y/100+1)*viewport[3]*.5f+viewport[1]),-projected[k].z/2000,valid};
                hit_vertices[t+k]=v;
                if(valid){if(v.x<pick_x0)pick_x0=v.x;if(v.x>pick_x1)pick_x1=v.x;if(v.y<pick_y0)pick_y0=v.y;if(v.y>pick_y1)pick_y1=v.y;}
            }
        }
        /* Conservative near-plane handling: skip a triangle that crosses it. */
        if(allvalid)for(int k=0;k<3;k++){
            glTexCoord2f(a->vertices[t+k].uv.u,a->vertices[t+k].uv.v);
            glVertex3f(projected[k].x,projected[k].y,projected[k].z);
        }
    }
    glEnd();
}
static void draw_world(void){
    if(!game_started||!wglGetCurrentContext()||!client_info(wglGetCurrentDC()))return;
    init_assets();if(!assets_ok)return;
    static int first;
    GLint matrix_mode;glGetIntegerv(GL_MATRIX_MODE,&matrix_mode);glPushAttrib(GL_ALL_ATTRIB_BITS);
    glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(-100,100,-100,100,0,2000);
    glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();
    glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LESS);glDepthMask(GL_TRUE);glDepthRange(0,1);
    glDisable(GL_LIGHTING);glDisable(GL_CULL_FACE);glDisable(GL_BLEND);glDisable(GL_ALPHA_TEST);glDisable(GL_FOG);
    glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);
    if(atomic(&props_visible)){draw_mesh(1);draw_mesh(0);}
    if(atomic(&posters_visible)){draw_mesh(2);draw_mesh(3);}
    glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(matrix_mode);glPopAttrib();
    if(!first){first=1;log_line("WORLD DRAW: native CPU projection + GL_LESS + depth writes; viewport %dx%d; client %dx%d; vase client bounds %.1f %.1f %.1f %.1f",viewport[2],viewport[3],client_width,client_height,pick_x0,pick_y0,pick_x1,pick_y1);}
}
static void __cdecl draw_hook(void *sprite,unsigned char pass){
    if(in_draw){original_draw(sprite,pass);return;}
    if(sprite)stage(sprite);
    int id=sprite?*(int*)((char*)sprite+4):-1;
    if(atomic(&photo_mode)&&(id==0||id==51))return;
    in_draw=1;original_draw(sprite,pass);
    if(sprite&&id==1&&atomic(&twins_on)){
        struct Vec3 p=vector(sprite,11),copy=p;copy.x+=85;
        memcpy((char*)sprite+0x1424c,&copy,sizeof copy);original_draw(sprite,pass);
        void *head=*(void**)((char*)sprite+0x19c360);
        if(head&&*(int*)((char*)head+4)==52)original_draw(head,pass);
        memcpy((char*)sprite+0x1424c,&p,sizeof p);original_draw(sprite,pass);
    }
    DWORD frame=*(DWORD*)(engine+FRAME_RVA);
    if(frame!=last_draw_frame){last_draw_frame=frame;draw_world();}
    in_draw=0;
}
static int inside_triangle(float x,float y,struct ScreenVertex a,struct ScreenVertex b,struct ScreenVertex c,float *depth){
    if(!a.valid||!b.valid||!c.valid)return 0;
    float den=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);if(fabsf(den)<.001f)return 0;
    float u=((b.y-c.y)*(x-c.x)+(c.x-b.x)*(y-c.y))/den;
    float v=((c.y-a.y)*(x-c.x)+(a.x-c.x)*(y-c.y))/den;float w=1-u-v;
    if(u<0||v<0||w<0)return 0;*depth=u*a.depth+v*b.depth+w*c.depth;return 1;
}
static void send_activation(void){
    DWORD now=GetTickCount();if(last_action&&now-last_action<750)return;
    last_action=now;sequence++;active_until=now+2400;
    FILE *f=fopen("room_lab/event.tmp","wb");
    if(!f){log_line("Cannot write Java event file");return;}
    fprintf(f,"%lu 1001 %.3f %.3f %.3f\n",sequence,assets[0].at.x,assets[0].at.y+16,assets[0].at.z);fclose(f);
    if(!MoveFileExA("room_lab/event.tmp","room_lab/event.txt",MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH))log_line("Java event rename failed: %lu",(unsigned long)GetLastError());
    log_line("CLICK #%lu: world vase hit, triangle + final-scene depth accepted; queued custom Java event object=1001, actor=player. NOT stock 49-slot activation/pickup.",sequence);
}
static void update_hit(void){
    hover=depth_hit=0;
    if(!game_started||!assets_ok||!atomic(&props_visible)||!game_window)return;
    DWORD pid=0;GetWindowThreadProcessId(GetForegroundWindow(),&pid);if(pid!=GetCurrentProcessId())return;
    POINT p;if(!GetCursorPos(&p)||!ScreenToClient(game_window,&p))return;
    if(p.x<0||p.x>=client_width||p.y<0||p.y>=client_height)return;
    float best=2;
    for(size_t i=0;i<assets[0].count;i+=3){float d;if(inside_triangle((float)p.x,(float)p.y,hit_vertices[i],hit_vertices[i+1],hit_vertices[i+2],&d)&&d<best)best=d;}
    if(best>1)return;
    float scene=1;glReadPixels(p.x,client_height-1-p.y,1,1,GL_DEPTH_COMPONENT,GL_FLOAT,&scene);
    /* Native line/fill depth offsets and rasterization need a small tolerance. */
    if(fabsf(scene-best)>.0015f)return;
    hover=depth_hit=1;
    if(InterlockedExchange(&click_queued,0)){
        log_line("Hit-test pixel %ld,%ld; mesh depth %.6f; scene depth %.6f",p.x,p.y,best,scene);send_activation();
    }
}
static void poll_ack(void){
    static DWORD last_poll;DWORD now=GetTickCount();if(now-last_poll<120)return;last_poll=now;
    FILE *f=fopen("room_lab/ack.txt","rb");if(!f)return;unsigned long n=0;int wme=0,gaze=0;
    int fields=fscanf(f,"%lu %d %d",&n,&wme,&gaze);fclose(f);
    if(fields==3&&n>ack_sequence&&n<=sequence&&wme&&gaze){ack_sequence=n;active_until=now+2600;log_line("JAVA ACK #%lu: Trip working-memory insertion verified by Java; JNI gaze request returned. Stock story may supersede gaze.",n);}
}
static void rect(float x,float y,float w,float h){glBegin(GL_QUADS);glVertex2f(x,y);glVertex2f(x+w,y);glVertex2f(x+w,y+h);glVertex2f(x,y+h);glEnd();}
static void text(float x,float y,const char *s){if(!font_base)return;glRasterPos2f(x,y);glListBase(font_base-32);glCallLists((GLsizei)strlen(s),GL_UNSIGNED_BYTE,s);}
static void hud(HDC dc){
    if(!game_started||!client_info(dc))return;
    GLint mode;glGetIntegerv(GL_MATRIX_MODE,&mode);glPushAttrib(GL_ALL_ATTRIB_BITS);
    glViewport(0,0,client_width,client_height);
    glMatrixMode(GL_PROJECTION);glPushMatrix();glLoadIdentity();glOrtho(0,client_width,0,client_height,-10,10);
    glMatrixMode(GL_MODELVIEW);glPushMatrix();glLoadIdentity();
    glDisable(GL_DEPTH_TEST);glDepthMask(GL_FALSE);glDisable(GL_LIGHTING);glDisable(GL_TEXTURE_2D);glDisable(GL_ALPHA_TEST);glDisable(GL_FOG);
    glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    if(!font_base){
        HFONT font=CreateFontA(-17,0,0,0,FW_NORMAL,0,0,0,ANSI_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,ANTIALIASED_QUALITY,DEFAULT_PITCH,"Arial");
        HGDIOBJ old=SelectObject(dc,font);font_base=glGenLists(96);if(!wglUseFontBitmapsA(dc,32,96,font_base))font_base=0;SelectObject(dc,old);DeleteObject(font);
    }
    glColor4f(.025f,.06f,.075f,.94f);rect(10,client_height-87,client_width-20,77);
    glColor3f(.41f,.84f,.82f);text(23,client_height-33,atomic(&photo_mode)?"ROOM LAB | F6 STAGED CAMERA (Trip pinned; Grace hidden)":"ROOM LAB | live game camera / native room projection + depth");
    glColor3f(.87f,.91f,.88f);text(23,client_height-56,"F5 side view  |  F6 stage  |  F7 props  |  F8 render twin  |  F9 posters");
    char status[180];
    if(sequence&&ack_sequence==sequence)snprintf(status,sizeof status,"JAVA ACK #%lu: custom WME in Trip + JNI gaze request. No stock pickup.",sequence);
    else if(sequence)snprintf(status,sizeof status,"Click #%lu sent. Waiting for the real Java backend...",sequence);
    else snprintf(status,sizeof status,"Click the 3D vase: triangle/depth hit -> custom Java event -> Trip gaze request");
    glColor3f(.92f,.76f,.43f);text(23,client_height-77,status);
    if(hover){
        /* Convert the cached client top-origin bounds to this HUD's bottom origin. */
        glColor4f(1,.82f,.35f,.9f);glLineWidth(2);glBegin(GL_LINE_LOOP);
        glVertex2f(pick_x0-3,client_height-pick_y1-3);glVertex2f(pick_x1+3,client_height-pick_y1-3);glVertex2f(pick_x1+3,client_height-pick_y0+3);glVertex2f(pick_x0-3,client_height-pick_y0+3);glEnd();
        text(pick_x0-6,client_height-pick_y0+10,"USE VASE");
    }
    glMatrixMode(GL_MODELVIEW);glPopMatrix();glMatrixMode(GL_PROJECTION);glPopMatrix();glMatrixMode(mode);glPopAttrib();
}
static BOOL WINAPI swap_hook(HDC dc){
    if(wglGetCurrentContext()){
        update_hit();InterlockedExchange(&click_queued,0);poll_ack();hud(dc);
    }
    return original_swap(dc);
}
static DWORD WINAPI input_thread(void *unused){
    (void)unused;int prev[6]={0};
    while(!atomic(&stop_worker)){
        DWORD pid=0;GetWindowThreadProcessId(GetForegroundWindow(),&pid);int focus=pid==GetCurrentProcessId();
        int keys[]={VK_F5,VK_F6,VK_F7,VK_F8,VK_F9,VK_LBUTTON};
        volatile LONG *states[]={&side_view,&photo_mode,&props_visible,&twins_on,&posters_visible};
        for(int i=0;i<6;i++){
            int down=focus&&(GetAsyncKeyState(keys[i])&0x8000)!=0;
            if(down&&!prev[i]){
                if(i==5)InterlockedExchange(&click_queued,1);
                else{LONG before=atomic(states[i]);InterlockedExchange(states[i],!before);log_line("F%d: %s %s",i+5,(const char*[]){"staged side view","staged camera","world props","render-only Trip twin","world wall posters"}[i],before?"OFF":"ON");}
            }
            prev[i]=down;
        }
        Sleep(12);
    }
    return 0;
}
__declspec(dllexport) int __cdecl InstallHooks(void){
    engine=(unsigned char*)GetModuleHandleA("animEngineDLL.dll");if(!engine)return 0;
    const unsigned char draw_sig[]={0x55,0x8b,0xec,0x81,0xec,0x74,0x05,0,0};
    const unsigned char project_sig[]={0x55,0x8b,0xec,0x83,0xec,0x74,0x53,0x56,0x57};
    if(memcmp(engine+DRAW_RVA,draw_sig,sizeof draw_sig)||memcmp(engine+PROJECT_RVA,project_sig,sizeof project_sig)){log_line("Version signature mismatch; refused");return 0;}
    HMODULE gdi=GetModuleHandleA("gdi32.dll");SwapFn system_swap=gdi?(SwapFn)GetProcAddress(gdi,"SwapBuffers"):NULL;
    if(!system_swap||*(SwapFn*)(engine+SWAP_RVA)!=system_swap){log_line("SwapBuffers IAT mismatch; refused");return 0;}
    unsigned char *target=engine+DRAW_RVA,*gate=VirtualAlloc(NULL,32,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);if(!gate)return 0;
    memcpy(gate,target,9);gate[9]=0xe9;*(int32_t*)(gate+10)=(int32_t)((uintptr_t)(target+9)-(uintptr_t)(gate+14));original_draw=(DrawFn)gate;
    DWORD old,ignored;if(!VirtualProtect(target,9,PAGE_EXECUTE_READWRITE,&old))return 0;
    target[0]=0xe9;*(int32_t*)(target+1)=(int32_t)((uintptr_t)draw_hook-(uintptr_t)(target+5));memset(target+5,0x90,4);FlushInstructionCache(GetCurrentProcess(),target,9);VirtualProtect(target,9,old,&ignored);
    SwapFn *iat=(SwapFn*)(engine+SWAP_RVA);if(!VirtualProtect(iat,sizeof *iat,PAGE_READWRITE,&old))return 0;
    original_swap=system_swap;*iat=swap_hook;VirtualProtect(iat,sizeof *iat,old,&ignored);
    project_world=(ProjectFn)(engine+PROJECT_RVA);
    if(!CreateThread(NULL,0,input_thread,NULL,0,NULL))return 0;
    log_line("Installed checked DrawSprite / SwapBuffers hooks + original CPU projector. Original DLL on disk unchanged. F6 is optional staging, not normal play.");return 1;
}
BOOL WINAPI DllMain(HINSTANCE h,DWORD reason,void *reserved){(void)reserved;if(reason==DLL_PROCESS_ATTACH)DisableThreadLibraryCalls(h);if(reason==DLL_PROCESS_DETACH)InterlockedExchange(&stop_worker,1);return TRUE;}
