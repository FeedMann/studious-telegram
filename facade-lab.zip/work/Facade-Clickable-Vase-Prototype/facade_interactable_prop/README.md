# Façade clickable-vase prototype

A small **32-bit Windows mod prototype** for the original Façade 1.1b engine. It draws a low-poly vase over the side table in a staged room view. The player can click its hit area and see a brief highlight/bob and a `PICKED!` label.

## Important: what this does—and does not—prove

This is a working **in-game visual + mod-side click prototype**, not a true native Façade room object. The vase is rendered by a mod hook in a fixed screen-projected position for the F6 camera. The original engine does not register it as a `Sprite`/room prop, and it has no native collision, depth testing, occlusion, or object-picking identity. The click reaction is owned by the mod; it does **not** raise the game's Java/JNI object-activation event or make Trip/Grace respond as they would to an original vase.

So this is useful progress, but it does **not** satisfy the stricter “like the original vases” criterion yet. The remaining work is to reverse engineer the original room-object registration/render path and its native-to-Java activation path.

## Included

- `bin/FacadeInteractable.dll` — the mod hook.
- `bin/facade-interactable-test.exe` — launcher that verifies the original engine DLL hash, loads the original engine, then installs the mod hooks.
- `src/` and `build.sh` — C sources and x86 MinGW build script.
- `launch-instructions.md` — separate run instructions.
- `TEST_RESULTS.md` — test method and exact outcome.
- `evidence/` — direct game-window captures and the runtime log.

The original game engine, proprietary assets, and Java files are **not included**.

## Controls

- **F6** — turn the wide staged room view and vase on/off. This pins the camera and Trip to staged poses and hides Grace's body/head drawing; restart the process to fully restore the natural scene after using it.
- **Left-click the vase** — show `PICKED!`, a highlight, and a short bob for about 1.8 seconds. This is a mod-only reaction.
- **F7** — hide/show the vase.

See `launch-instructions.md` before running it.

## Compatibility and safety

The address checks are for the original `animEngineDLL.dll` with SHA-256:

```text
815337c6f7fe05da8a99b5f261a182142907cae6f21b915b03fe6a8c1581016c
```

The launcher refuses other builds. It loads the game's original DLL and patches functions **in memory only**. The original engine file is not overwritten. The prototype is 32-bit x86; on 64-bit Windows it relies on WoW64. The game directory will receive the two added prototype files and a `facade-interactable-prop.log` when run.

## Build

On a system with `i686-w64-mingw32-gcc`:

```sh
bash build.sh
```

This creates both outputs under `bin/`. The package already includes a tested build.
