# Test results: clickable-vase prototype

## Tested build and environment

- Original Façade 1.1b `animEngineDLL.dll`, SHA-256 `815337c6f7fe05da8a99b5f261a182142907cae6f21b915b03fe6a8c1581016c`.
- x86 Windows DLL and launcher built with `i686-w64-mingw32-gcc`.
- Ran the original game under 32-bit Wine, Xvfb, and software Mesa OpenGL at a 1016×734 client size.
- The engine DLL on disk was not replaced or edited; only the two prototype files were added to the temporary test install. Hooks were installed in the running process.

## Results

| Check | Result |
|---|---|
| Launcher verifies exact original engine build | Pass |
| Version-checked `DrawSprite` staging hook installs | Pass |
| Version-checked `SwapBuffers` hook installs in the original WGL context | Pass |
| F6 staged view shows the vase visually over the side table | Pass |
| Click at the vase's hit area triggers the mod-side response | Pass — runtime log records `local activation #1` |
| `PICKED!`/highlight appears after click | Pass — see `evidence/final_wide_clicked.png` |
| F7 hides and shows the vase | Pass — both transitions appear in the runtime log |
| Original Java/JNI vase event, native room-object registration, collision/depth/occlusion | **Not implemented / not claimed** |

## Evidence

- `evidence/final_wide_idle.png` — staged game view with the vase on the side table and `CLICK` prompt.
- `evidence/final_wide_clicked.png` — same view after clicking; `PICKED!` and the hover/activation outline are visible.
- `evidence/runtime_log.txt` — log from the tested run, including hook installation, F6 stage, click hit, and F7 hide/show.

The screenshot demonstrates an in-game mod overlay visually aligned to the table in a fixed camera shot. It does **not** establish a genuine world-space object: the prop is a fixed screen projection with no native room registration or AI interaction.
