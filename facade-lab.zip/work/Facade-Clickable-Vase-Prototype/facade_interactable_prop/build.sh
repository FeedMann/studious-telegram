#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
CC="${CC:-i686-w64-mingw32-gcc}"
mkdir -p bin
"$CC" -std=c11 -O2 -Wall -Wextra -Wno-unused-parameter -shared \
  -o bin/FacadeInteractable.dll src/facade_interactable.c \
  -lopengl32 -lgdi32 -luser32 -lm -static-libgcc
"$CC" -std=c11 -O2 -Wall -Wextra -Wno-unused-parameter -mwindows \
  -o bin/facade-interactable-test.exe src/launcher.c \
  -ladvapi32 -luser32 -static-libgcc
printf 'Built:\n  %s\n  %s\n' \
  "$PWD/bin/FacadeInteractable.dll" \
  "$PWD/bin/facade-interactable-test.exe"
