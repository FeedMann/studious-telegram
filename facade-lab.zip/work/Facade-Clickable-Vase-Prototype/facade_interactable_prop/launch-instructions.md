# Launching the clickable-vase prototype

## Before you start

Use an installed, original **Façade 1.1b** copy. This is an x86-only prototype. It will run on 32-bit Windows or on x64 Windows using WoW64; it does not support another engine build.

The launcher checks that the nearby `animEngineDLL.dll` has this SHA-256 before installing hooks:

```text
815337c6f7fe05da8a99b5f261a182142907cae6f21b915b03fe6a8c1581016c
```

If it reports a version/hash mismatch, stop—do not try to bypass the check.

## Run

1. Find Façade's data/working directory containing the original `animEngineDLL.dll` (usually `util\\sources\\facade`).
2. Copy these two files from this package's `bin/` folder into that directory:
   - `FacadeInteractable.dll`
   - `facade-interactable-test.exe`
3. Run **`facade-interactable-test.exe`**, not `animEngineStarter.exe`.
4. Start a scene in the game and wait until the room/Trip intro is visible.
5. Press **F6** to switch to the wide staged view. The mod places the vase over the side table in that fixed view.
6. **Left-click the vase.** The vase should highlight/bob and show `PICKED!`; the mod writes a hit confirmation to `facade-interactable-prop.log`.
7. Press **F7** to hide/show the vase. Press **F6** to leave the staged view.
8. Quit the prototype process when finished. Run the game's normal starter for an unmodified session.

F6 deliberately changes the camera/Trip staging and suppresses Grace's body/head draw in that view. Restarting the process is the safest way to restore the natural scene after testing. The prototype does not write to the original engine DLL; remove the two added files and `facade-interactable-prop.log` to clean up.

## If it does not start

- Confirm both prototype files are beside the original engine DLL, not beside a shortcut elsewhere.
- Confirm the launcher accepted the original engine hash.
- Check `facade-interactable-prop.log` for a hook/signature failure.
- The first game launch may take a while while Façade loads. Wait for the room scene before pressing F6.
