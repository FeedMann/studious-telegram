/*
 * Façade 1.1b staged-view clickable vase prototype.
 *
 * This DLL never replaces animEngineDLL.dll. It installs a version-checked
 * DrawSprite detour (for the original F6 camera/Trip staging experiment) and a
 * SwapBuffers import hook (for drawing the mod-owned vase in the current OpenGL
 * context). The vase is a camera-pinned, screen-projected prop placed over the
 * side table in the fixed F6 view. It is NOT a registered native room object,
 * has no engine collision/depth/occlusion, and does not call Façade's Java/AI
 * object-interaction path. A click in its hitbox produces a mod-only reaction.
 *
 * Addresses apply only to the unmodified original 1.1b engine DLL with SHA-256:
 * 815337c6f7fe05da8a99b5f261a182142907cae6f21b915b03fe6a8c1581016c
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <GL/gl.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

#if !defined(__i386__)
#error This experiment requires a 32-bit x86 Windows build.
#endif

#define DRAW_SPRITE_RVA       0x8c6a0u
#define SWAPBUFFERS_IAT_RVA   0x9be790u
#define GETPOS_SLOT           11
#define TRIP_ID               1
#define FRAME_RVA             0x83f62cu
#define PLAYER_PTR_RVA        0x979474u
#define TRIP_PTR_RVA          0x979480u

struct Vec3 { float x, y, z; };
typedef void (__cdecl *DrawSpriteFn)(void *, unsigned char);
typedef BOOL (WINAPI *SwapBuffersFn)(HDC);
typedef struct Vec3 *(__attribute__((thiscall)) *GetVecFn)(void *, struct Vec3 *);
typedef void (__attribute__((thiscall)) *NativePosFn)(void *, float, float, float, float);
typedef void (__attribute__((thiscall)) *NativeRotFn)(void *, float, float, float);

static unsigned char *engine_base;
static DrawSpriteFn original_draw;
static SwapBuffersFn original_swap_buffers;
static HANDLE input_worker;
static volatile LONG stop_worker;
static volatile LONG photo_mode;
static volatile LONG prop_visible = 1;
static volatile LONG prop_hovered;
static volatile LONG activation_until;
static volatile LONG activation_count;
static volatile LONG anchor_logged;
static volatile LONG viewport_x, viewport_y, viewport_w, viewport_h;
static volatile LONG client_w, client_h;
static volatile LONG_PTR game_hwnd;
static LONG intro_saved;
static struct Vec3 intro_camera_pos, intro_camera_rot, intro_trip_pos, intro_trip_rot;
static struct Vec3 photo_camera_pos;
static DWORD photo_frame = 0xffffffffu;
static int in_draw_hook;

static void log_line(const char *message) {
    FILE *f = fopen("facade-interactable-prop.log", "a");
    if (f) {
        fprintf(f, "%lu: %s\n", (unsigned long)GetTickCount(), message);
        fclose(f);
    }
}

static LONG load_long(volatile LONG *p) {
    return InterlockedCompareExchange(p, 0, 0);
}

static struct Vec3 read_vector(void *sprite, unsigned slot) {
    struct Vec3 out = {0, 0, 0};
    uintptr_t *vtable = *(uintptr_t **)sprite;
    ((GetVecFn)vtable[slot])(sprite, &out);
    return out;
}

static void native_pose(void *sprite, struct Vec3 position, struct Vec3 rotation) {
    uintptr_t *vtable = *(uintptr_t **)sprite;
    ((NativePosFn)vtable[15])(sprite, position.x, position.y, position.z, -1.0f);
    /* The original SetRotation virtual takes three floats. */
    ((NativeRotFn)vtable[16])(sprite, rotation.x, rotation.y, rotation.z);
}

static void snapshot_and_stage(void *sprite) {
    if (!engine_base) return;
    void *player = *(void **)(engine_base + PLAYER_PTR_RVA);
    void *trip = *(void **)(engine_base + TRIP_PTR_RVA);
    if (!player || !trip || *(int *)((unsigned char *)player + 4) != 2) return;

    if (!intro_saved && sprite == trip) {
        intro_camera_pos = read_vector(player, GETPOS_SLOT);
        intro_camera_rot = read_vector(player, GETPOS_SLOT + 1);
        intro_trip_pos = read_vector(trip, GETPOS_SLOT);
        intro_trip_rot = read_vector(trip, GETPOS_SLOT + 1);
        /* Use the same wide photo-camera framing measured in the earlier
           original-engine render test, so the side table stays in view. */
        float yaw = intro_camera_rot.y * (3.14159265358979323846f / 180.0f);
        photo_camera_pos.x = intro_trip_pos.x - 190.0f * sinf(yaw);
        photo_camera_pos.y = 65.0f;
        photo_camera_pos.z = intro_trip_pos.z + 190.0f * cosf(yaw);
        intro_saved = 1;
        char message[240];
        snprintf(message, sizeof message,
                 "F6 staging snapshot saved: camera %.2f %.2f %.2f; Trip %.2f %.2f %.2f",
                 intro_camera_pos.x, intro_camera_pos.y, intro_camera_pos.z,
                 intro_trip_pos.x, intro_trip_pos.y, intro_trip_pos.z);
        log_line(message);
    }

    if (intro_saved && load_long(&photo_mode)) {
        DWORD frame = *(DWORD *)(engine_base + FRAME_RVA);
        if (photo_frame != frame) {
            photo_frame = frame;
            /* Keep Trip at the original intro pose and use a wide framing
               camera, staged through the engine's native camera pose method.
               This is a viewer shot, not an NPC/object spawn. */
            native_pose(player, photo_camera_pos, intro_camera_rot);
            native_pose(trip, intro_trip_pos, intro_trip_rot);
        }
    }
}

static void __cdecl draw_sprite_hook(void *sprite, unsigned char pass) {
    if (sprite && !in_draw_hook) {
        snapshot_and_stage(sprite);
        int id = *(int *)((unsigned char *)sprite + 4);
        /* Grace body/head are hidden only in the optional F6 staging view. */
        if (load_long(&photo_mode) && (id == 0 || id == 51)) return;
    }
    in_draw_hook = 1;
    original_draw(sprite, pass);
    in_draw_hook = 0;
}

static void draw_quad(float x0, float y0, float x1, float y1) {
    glBegin(GL_QUADS);
    glVertex3f(x0, y0, 0.0f);
    glVertex3f(x1, y0, 0.0f);
    glVertex3f(x1, y1, 0.0f);
    glVertex3f(x0, y1, 0.0f);
    glEnd();
}

static void draw_ellipse(float cx, float cy, float rx, float ry, float z, int segments) {
    glBegin(GL_TRIANGLE_FAN);
    glVertex3f(cx, cy, z);
    for (int i = 0; i <= segments; ++i) {
        float a = (float)i * 6.28318530718f / (float)segments;
        glVertex3f(cx + cosf(a) * rx, cy + sinf(a) * ry, z);
    }
    glEnd();
}

static void draw_vase_body(float cx, float base, float bob, int highlighted) {
    /* Low-poly, mod-owned lathed mesh. Coordinates are pixels in the staged
       view's orthographic overlay, not Façade room/world coordinates. */
    static const float ring_y[] = {0, 4, 12, 25, 38, 49, 58, 64};
    static const float ring_r[] = {9, 12, 15, 18, 16, 10, 8, 11};
    const int ring_count = (int)(sizeof ring_y / sizeof ring_y[0]);
    const int sides = 12;
    float wobble = highlighted ? sinf((float)GetTickCount() * 0.018f) * 3.2f : 0.0f;
    float color_boost = highlighted ? 0.20f : 0.0f;

    /* Soft table shadow, intentionally overlayed rather than depth-tested. */
    glColor4f(0.08f, 0.05f, 0.04f, 0.35f);
    draw_ellipse(cx, base + 2.0f, 17.0f, 4.2f, -1.0f, 20);

    for (int ring = 0; ring < ring_count - 1; ++ring) {
        glBegin(GL_QUADS);
        for (int side = 0; side < sides; ++side) {
            float a0 = (float)side * 6.28318530718f / (float)sides + wobble * 0.01745329252f;
            float a1 = (float)(side + 1) * 6.28318530718f / (float)sides + wobble * 0.01745329252f;
            float shade = (side % 4 == 0) ? 0.10f : ((side % 4 == 1) ? 0.02f : ((side % 4 == 2) ? -0.06f : 0.04f));
            float red = 0.52f + shade + color_boost;
            float green = 0.22f + shade * 0.55f + color_boost * 0.45f;
            float blue = 0.12f + shade * 0.25f + color_boost * 0.20f;
            if (red < 0) red = 0;
            if (green < 0) green = 0;
            if (blue < 0) blue = 0;
            glColor4f(red, green, blue, 1.0f);
            glVertex3f(cx + cosf(a0) * ring_r[ring],     base + ring_y[ring] + bob,  sinf(a0) * 4.0f);
            glVertex3f(cx + cosf(a1) * ring_r[ring],     base + ring_y[ring] + bob,  sinf(a1) * 4.0f);
            glVertex3f(cx + cosf(a1) * ring_r[ring + 1], base + ring_y[ring + 1] + bob, sinf(a1) * 4.0f);
            glVertex3f(cx + cosf(a0) * ring_r[ring + 1], base + ring_y[ring + 1] + bob, sinf(a0) * 4.0f);
        }
        glEnd();
    }

    /* Raised lip and dark opening make the silhouette read as a vase. */
    glColor4f(0.76f + color_boost, 0.40f + color_boost * 0.4f, 0.20f, 1.0f);
    draw_ellipse(cx, base + 64.0f + bob, 11.2f, 3.7f, 0.8f, 20);
    glColor4f(0.16f, 0.07f, 0.035f, 1.0f);
    draw_ellipse(cx, base + 64.5f + bob, 6.7f, 2.0f, 1.2f, 20);

    /* Small painted highlight on the front-left facet. */
    glColor4f(0.93f, 0.63f, 0.40f, highlighted ? 0.92f : 0.58f);
    glBegin(GL_QUADS);
    glVertex3f(cx - 7.4f, base + 15.0f + bob, 5.2f);
    glVertex3f(cx - 5.4f, base + 16.0f + bob, 5.2f);
    glVertex3f(cx - 4.8f, base + 45.0f + bob, 5.2f);
    glVertex3f(cx - 6.8f, base + 44.0f + bob, 5.2f);
    glEnd();
}

static const unsigned char *glyph_rows(char ch) {
    /* 5x7 uppercase bitmap font; only the prompt/result strings use it. */
    static const unsigned char C[7] = {14,17,16,16,16,17,14};
    static const unsigned char D[7] = {30,17,17,17,17,17,30};
    static const unsigned char E[7] = {31,16,16,30,16,16,31};
    static const unsigned char I[7] = {31,4,4,4,4,4,31};
    static const unsigned char K[7] = {17,18,20,24,20,18,17};
    static const unsigned char L[7] = {16,16,16,16,16,16,31};
    static const unsigned char P[7] = {30,17,17,30,16,16,16};
    static const unsigned char X[7] = {17,17,10,4,10,17,17};
    static const unsigned char bang[7] = {4,4,4,4,4,0,4};
    switch (ch) {
        case 'C': return C; case 'D': return D; case 'E': return E;
        case 'I': return I; case 'K': return K; case 'L': return L;
        case 'P': return P; case 'X': return X; case '!': return bang;
        default: return NULL;
    }
}

static void draw_text_5x7(const char *text, float x, float y, float scale) {
    glBegin(GL_QUADS);
    for (size_t i = 0; text[i]; ++i) {
        const unsigned char *rows = glyph_rows(text[i]);
        if (!rows) continue;
        for (int row = 0; row < 7; ++row) {
            for (int col = 0; col < 5; ++col) {
                if (rows[row] & (1u << (4 - col))) {
                    float px = x + (float)i * 6.0f * scale + (float)col * scale;
                    float py = y + (float)(6 - row) * scale;
                    glVertex3f(px, py, 2.5f);
                    glVertex3f(px + scale * 0.84f, py, 2.5f);
                    glVertex3f(px + scale * 0.84f, py + scale * 0.84f, 2.5f);
                    glVertex3f(px, py + scale * 0.84f, 2.5f);
                }
            }
        }
    }
    glEnd();
}

static void draw_bubble(float cx, float bottom, const char *label, int active) {
    float scale = 1.35f;
    float text_w = (float)strlen(label) * 6.0f * scale;
    float box_w = text_w + 14.0f;
    float box_h = 25.0f;
    float x = cx - box_w * 0.5f;
    float y = bottom + 75.0f;
    glDisable(GL_TEXTURE_2D);
    glColor4f(active ? 0.90f : 0.99f, active ? 0.96f : 0.91f,
              active ? 0.80f : 0.79f, 0.97f);
    draw_quad(x, y, x + box_w, y + box_h);
    glColor4f(active ? 0.12f : 0.31f, active ? 0.42f : 0.16f,
              active ? 0.24f : 0.09f, 1.0f);
    glLineWidth(1.6f);
    glBegin(GL_LINE_LOOP);
    glVertex3f(x, y, 2.6f); glVertex3f(x + box_w, y, 2.6f);
    glVertex3f(x + box_w, y + box_h, 2.6f); glVertex3f(x, y + box_h, 2.6f);
    glEnd();
    glBegin(GL_TRIANGLES);
    glVertex3f(cx - 4.0f, y, 2.6f); glVertex3f(cx + 4.0f, y, 2.6f);
    glVertex3f(cx, y - 5.0f, 2.6f);
    glEnd();
    glColor4f(active ? 0.05f : 0.35f, active ? 0.28f : 0.08f,
              active ? 0.11f : 0.05f, 1.0f);
    draw_text_5x7(label, x + 7.0f, y + 8.0f, scale);
}

static void draw_interactable_prop(void) {
    if (!load_long(&photo_mode) || !load_long(&prop_visible)) return;
    if (!wglGetCurrentContext()) return;

    GLint viewport[4] = {0,0,0,0}, old_matrix_mode = GL_MODELVIEW;
    glGetIntegerv(GL_VIEWPORT, viewport);
    glGetIntegerv(GL_MATRIX_MODE, &old_matrix_mode);
    if (viewport[2] < 160 || viewport[3] < 160) return;

    InterlockedExchange(&viewport_x, viewport[0]);
    InterlockedExchange(&viewport_y, viewport[1]);
    InterlockedExchange(&viewport_w, viewport[2]);
    InterlockedExchange(&viewport_h, viewport[3]);
    HWND hwnd = WindowFromDC(wglGetCurrentDC());
    if (hwnd) {
        RECT r;
        if (GetClientRect(hwnd, &r)) {
            InterlockedExchange(&client_w, r.right - r.left);
            InterlockedExchange(&client_h, r.bottom - r.top);
            InterlockedExchangePointer((PVOID volatile *)&game_hwnd, hwnd);
        }
    }

    /* Fixed screen-pixel anchor over the side table in the wide F6 view.
       The engine viewport is 1016x1016 while its visible client area is shorter;
       client height, not viewport height, is therefore used for the table Y. */
    int cw = load_long(&client_w), ch = load_long(&client_h);
    if (cw <= 0) cw = viewport[2];
    if (ch <= 0) ch = viewport[3];
    const float cx = (float)viewport[0] + (float)cw * 0.8125f;
    const float base = (float)viewport[1] + (float)ch * 0.607f;
    if (InterlockedCompareExchange(&anchor_logged, 1, 0) == 0) {
        char message[240];
        int click_x = (int)(cx - viewport[0]);
        int click_y = ch - (int)(base + 32.0f - viewport[1]);
        snprintf(message, sizeof message,
                 "F6 staged prop visible: fixed table overlay at GL %.1f,%.1f; approximate client click center %d,%d",
                 cx, base, click_x, click_y);
        log_line(message);
    }

    DWORD now = GetTickCount();
    LONG until = load_long(&activation_until);
    int active = (until != 0 && (LONG)((DWORD)until - now) > 0);
    int hovered = load_long(&prop_hovered) != 0;
    float bob = active ? (1.0f - cosf((float)(now % 628u) * 0.01f)) * 2.4f : 0.0f;

    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glMatrixMode(GL_PROJECTION); glPushMatrix(); glLoadIdentity();
    glOrtho(viewport[0], viewport[0] + viewport[2],
            viewport[1], viewport[1] + viewport[3], -10.0, 10.0);
    glMatrixMode(GL_MODELVIEW); glPushMatrix(); glLoadIdentity();
    glDisable(GL_DEPTH_TEST); glDepthMask(GL_FALSE);
    glDisable(GL_LIGHTING); glDisable(GL_CULL_FACE); glDisable(GL_TEXTURE_2D);
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glShadeModel(GL_FLAT);

    draw_vase_body(cx, base, bob, active || hovered);

    if (hovered) {
        glColor4f(1.0f, 0.88f, 0.30f, 0.82f);
        glLineWidth(2.0f);
        glBegin(GL_LINE_LOOP);
        glVertex3f(cx - 23.0f, base - 2.0f, 2.0f);
        glVertex3f(cx + 23.0f, base - 2.0f, 2.0f);
        glVertex3f(cx + 23.0f, base + 70.0f, 2.0f);
        glVertex3f(cx - 23.0f, base + 70.0f, 2.0f);
        glEnd();
    }

    if (active) draw_bubble(cx, base, "PICKED!", 1);
    else draw_bubble(cx, base, "CLICK", 0);

    glMatrixMode(GL_MODELVIEW); glPopMatrix();
    glMatrixMode(GL_PROJECTION); glPopMatrix();
    glMatrixMode(old_matrix_mode);
    glPopAttrib();
}

static BOOL WINAPI swap_buffers_hook(HDC dc) {
    static volatile LONG active_logged;
    if (wglGetCurrentContext() && InterlockedCompareExchange(&active_logged, 1, 0) == 0)
        log_line("SwapBuffers hook active with the original WGL context.");
    draw_interactable_prop();
    return original_swap_buffers(dc);
}

static void update_mouse_state(int focused, int left_down) {
    if (!focused || !load_long(&photo_mode) || !load_long(&prop_visible)) {
        InterlockedExchange(&prop_hovered, 0);
        return;
    }
    HWND hwnd = (HWND)InterlockedCompareExchangePointer((PVOID volatile *)&game_hwnd, NULL, NULL);
    if (!hwnd) hwnd = GetForegroundWindow();
    POINT p;
    RECT r;
    if (!GetCursorPos(&p) || !ScreenToClient(hwnd, &p) || !GetClientRect(hwnd, &r)) {
        InterlockedExchange(&prop_hovered, 0);
        return;
    }
    int cw = r.right - r.left, ch = r.bottom - r.top;
    int vx = load_long(&viewport_x), vy = load_long(&viewport_y);
    int vw = load_long(&viewport_w), vh = load_long(&viewport_h);
    if (cw <= 0 || ch <= 0 || vw <= 0 || vh <= 0) {
        InterlockedExchange(&prop_hovered, 0);
        return;
    }
    /* glOrtho spans one GL unit per viewport pixel. The window clips the
       oversized vertical viewport but does not scale mouse pixels. */
    float gx = (float)vx + (float)p.x;
    float gy = (float)vy + (float)(ch - p.y);
    float cx = (float)vx + (float)cw * 0.8125f;
    float base = (float)vy + (float)ch * 0.607f;
    int hit = (gx >= cx - 23.0f && gx <= cx + 23.0f && gy >= base - 2.0f && gy <= base + 70.0f);
    InterlockedExchange(&prop_hovered, hit);
    if (left_down && hit) {
        DWORD now = GetTickCount();
        InterlockedExchange(&activation_until, (LONG)(now + 1800u));
        LONG n = InterlockedIncrement(&activation_count);
        char message[160];
        snprintf(message, sizeof message, "Mouse click hit the mod-owned prop; local activation #%ld (no native AI/object event)", n);
        log_line(message);
    }
}

static DWORD WINAPI input_thread(void *unused) {
    (void)unused;
    int prev6 = 0, prev7 = 0, prev_left = 0;
    while (!load_long(&stop_worker)) {
        DWORD pid = 0;
        HWND foreground = GetForegroundWindow();
        GetWindowThreadProcessId(foreground, &pid);
        int focused = (pid == GetCurrentProcessId());
        int key6 = focused && ((GetAsyncKeyState(VK_F6) & 0x8000) != 0);
        int key7 = focused && ((GetAsyncKeyState(VK_F7) & 0x8000) != 0);
        if (key6 && !prev6) {
            LONG before = load_long(&photo_mode);
            InterlockedExchange(&photo_mode, !before);
            InterlockedExchange(&anchor_logged, 0);
            InterlockedExchange(&prop_hovered, 0);
            log_line(before
                ? "F6: staged view OFF (restart to fully restore original scene poses)"
                : "F6: wide staged view ON; Trip pinned, Grace hidden. Prop is a fixed overlay in this view.");
        }
        if (key7 && !prev7) {
            LONG before = load_long(&prop_visible);
            InterlockedExchange(&prop_visible, !before);
            log_line(before ? "F7: mod-owned vase hidden" : "F7: mod-owned vase visible");
        }
        int left = focused && ((GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0);
        update_mouse_state(focused, left && !prev_left);
        prev6 = key6; prev7 = key7; prev_left = left;
        Sleep(15);
    }
    return 0;
}

static int install_draw_hook(void) {
    unsigned char *target = engine_base + DRAW_SPRITE_RVA;
    const unsigned char expected[9] = {0x55,0x8b,0xec,0x81,0xec,0x74,0x05,0x00,0x00};
    if (memcmp(target, expected, sizeof expected) != 0) {
        log_line("DrawSprite prologue mismatch; refusing to patch this engine.");
        return 0;
    }
    unsigned char *gate = (unsigned char *)VirtualAlloc(NULL, 32, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!gate) { log_line("Could not allocate DrawSprite trampoline."); return 0; }
    memcpy(gate, target, 9);
    gate[9] = 0xe9;
    *(int32_t *)(gate + 10) = (int32_t)((uintptr_t)(target + 9) - (uintptr_t)(gate + 14));
    original_draw = (DrawSpriteFn)gate;

    DWORD old_protect = 0;
    if (!VirtualProtect(target, 9, PAGE_EXECUTE_READWRITE, &old_protect)) {
        log_line("Could not make DrawSprite writable."); return 0;
    }
    target[0] = 0xe9;
    *(int32_t *)(target + 1) = (int32_t)((uintptr_t)draw_sprite_hook - (uintptr_t)(target + 5));
    memset(target + 5, 0x90, 4);
    FlushInstructionCache(GetCurrentProcess(), target, 9);
    DWORD ignored = 0;
    VirtualProtect(target, 9, old_protect, &ignored);
    log_line("Version-checked original-engine DrawSprite staging hook installed.");
    return 1;
}

static int install_swap_hook(void) {
    HMODULE gdi = GetModuleHandleA("gdi32.dll");
    if (!gdi) { log_line("GDI32 is not loaded; refusing SwapBuffers hook."); return 0; }
    uintptr_t *iat = (uintptr_t *)(engine_base + SWAPBUFFERS_IAT_RVA);
    union SwapPointerBits { SwapBuffersFn function; uintptr_t bits; } system_swap, hook_swap;
    system_swap.function = (SwapBuffersFn)GetProcAddress(gdi, "SwapBuffers");
    _Static_assert(sizeof(SwapBuffersFn) == sizeof(uintptr_t), "x86 function pointer must fit an IAT entry");
    if (!system_swap.function || *iat != system_swap.bits) {
        log_line("Original 1.1b SwapBuffers IAT pointer mismatch; refusing to patch.");
        return 0;
    }
    original_swap_buffers = system_swap.function;
    hook_swap.function = swap_buffers_hook;
    DWORD old_protect = 0;
    if (!VirtualProtect(iat, sizeof(uintptr_t), PAGE_READWRITE, &old_protect)) {
        log_line("Could not make the original engine IAT writable."); return 0;
    }
    *iat = hook_swap.bits;
    FlushInstructionCache(GetCurrentProcess(), iat, sizeof(uintptr_t));
    DWORD ignored = 0;
    VirtualProtect(iat, sizeof(uintptr_t), old_protect, &ignored);
    log_line("Version-checked original-engine SwapBuffers hook installed.");
    return 1;
}

__declspec(dllexport) int __cdecl InstallHooks(void) {
    HMODULE engine = GetModuleHandleA("animEngineDLL.dll");
    if (!engine) { log_line("Original animEngineDLL.dll is not loaded; refusing to hook."); return 0; }
    engine_base = (unsigned char *)engine;

    /* Both signatures are checked before either patch is attempted. */
    unsigned char *draw_target = engine_base + DRAW_SPRITE_RVA;
    const unsigned char expected[9] = {0x55,0x8b,0xec,0x81,0xec,0x74,0x05,0x00,0x00};
    if (memcmp(draw_target, expected, sizeof expected) != 0) {
        log_line("Engine signature check failed; no hook installed."); return 0;
    }
    HMODULE gdi = GetModuleHandleA("gdi32.dll");
    if (!gdi) { log_line("GDI32 is missing; no hook installed."); return 0; }
    uintptr_t *iat = (uintptr_t *)(engine_base + SWAPBUFFERS_IAT_RVA);
    union SwapPointerBits { SwapBuffersFn function; uintptr_t bits; } system_swap;
    system_swap.function = (SwapBuffersFn)GetProcAddress(gdi, "SwapBuffers");
    _Static_assert(sizeof(SwapBuffersFn) == sizeof(uintptr_t), "x86 function pointer must fit an IAT entry");
    if (!system_swap.function || *iat != system_swap.bits) {
        log_line("Engine IAT signature check failed; no hook installed."); return 0;
    }

    if (!install_draw_hook()) return 0;
    if (!install_swap_hook()) {
        log_line("SwapBuffers hook failed after DrawSprite hook; exiting is safer than continuing.");
        return 0;
    }
    input_worker = CreateThread(NULL, 0, input_thread, NULL, 0, NULL);
    if (!input_worker) { log_line("Input worker could not start."); return 0; }
    log_line("Prototype ready. F6 stages the fixed camera; left-click the vase for a mod-only response; F7 hides/shows it.");
    return 1;
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, void *reserved) {
    (void)reserved;
    if (reason == DLL_PROCESS_ATTACH) DisableThreadLibraryCalls(h);
    if (reason == DLL_PROCESS_DETACH) InterlockedExchange(&stop_worker, 1);
    return TRUE;
}
