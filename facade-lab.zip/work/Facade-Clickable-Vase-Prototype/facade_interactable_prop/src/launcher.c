/* Small x86 launcher: loads the verified original engine and the prototype DLL. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wincrypt.h>
#include <stdio.h>
#include <string.h>

typedef int (__cdecl *EngineMainFn)(HINSTANCE, HINSTANCE, LPSTR, int);
typedef int (__cdecl *InstallFn)(void);

static int matches_original_engine(void) {
    static const unsigned char expected[32] = {
        0x81,0x53,0x37,0xc6,0xf7,0xfe,0x05,0xda,0x8a,0x99,0xb5,0xf2,0x61,0xa1,0x82,0x14,
        0x29,0x07,0xca,0xe6,0xf2,0x1b,0x91,0x5b,0x03,0xfe,0x6a,0x8c,0x15,0x81,0x01,0x6c
    };
    HCRYPTPROV provider = 0;
    HCRYPTHASH hash = 0;
    HANDLE file = CreateFileA("animEngineDLL.dll", GENERIC_READ, FILE_SHARE_READ,
                              NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (file == INVALID_HANDLE_VALUE) return 0;
    int ok = CryptAcquireContextA(&provider, NULL, NULL, PROV_RSA_AES, CRYPT_VERIFYCONTEXT)
          && CryptCreateHash(provider, CALG_SHA_256, 0, 0, &hash);
    unsigned char buffer[65536], digest[32];
    DWORD read_count = 0, digest_size = sizeof digest;
    if (ok) {
        while (ReadFile(file, buffer, sizeof buffer, &read_count, NULL) && read_count) {
            if (!CryptHashData(hash, buffer, read_count, 0)) { ok = 0; break; }
        }
    }
    if (ok) ok = CryptGetHashParam(hash, HP_HASHVAL, digest, &digest_size, 0)
                 && digest_size == sizeof expected && memcmp(digest, expected, sizeof expected) == 0;
    CloseHandle(file);
    if (hash) CryptDestroyHash(hash);
    if (provider) CryptReleaseContext(provider, 0);
    return ok;
}

int WINAPI WinMain(HINSTANCE instance, HINSTANCE previous, LPSTR command_line, int show) {
    char path[MAX_PATH];
    DWORD length = GetModuleFileNameA(NULL, path, MAX_PATH);
    if (length && length < MAX_PATH) {
        char *slash = strrchr(path, '\\');
        if (slash) { *slash = 0; SetCurrentDirectoryA(path); }
    }
    if (!matches_original_engine()) {
        MessageBoxA(NULL,
            "This prototype only supports the verified original Façade 1.1b animEngineDLL.dll.\n\n"
            "Put this launcher and FacadeInteractable.dll beside the original game files. The launcher will not patch an unknown engine.",
            "Façade clickable-prop prototype", MB_OK | MB_ICONERROR);
        return 1;
    }

    HMODULE engine = LoadLibraryA("animEngineDLL.dll");
    if (!engine) {
        MessageBoxA(NULL, "The original animEngineDLL.dll could not be loaded.",
                    "Façade clickable-prop prototype", MB_OK | MB_ICONERROR);
        return 2;
    }
    HMODULE mod = LoadLibraryA("FacadeInteractable.dll");
    InstallFn install = mod ? (InstallFn)GetProcAddress(mod, "InstallHooks") : NULL;
    if (!install || !install()) {
        MessageBoxA(NULL,
            "The prototype hook could not initialize. Check facade-interactable-prop.log.\n\n"
            "If a hook failed, close this process; the original game files remain unchanged.",
            "Façade clickable-prop prototype", MB_OK | MB_ICONERROR);
        return 3;
    }

    EngineMainFn engine_main = (EngineMainFn)GetProcAddress(
        engine, "?AnimEngineWinMain@@YAHPAUHINSTANCE__@@0PADH@Z");
    if (!engine_main) {
        MessageBoxA(NULL, "The original engine entry point was not found.",
                    "Façade clickable-prop prototype", MB_OK | MB_ICONERROR);
        return 4;
    }
    return engine_main(instance, previous, command_line, show);
}
