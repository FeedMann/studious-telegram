# Trip Twins — original-engine render experiment

A small **Windows x86 native DLL and launcher** for the original Façade 1.1b engine. This is a rendering experiment, not a rebuilt game. It draws the original Trip model at a second position, including its separately attached head.

## Run it

1. Install the original **Façade 1.1b** game normally.
2. Find the directory containing both `animEngineStarter.exe` and `animEngineDLL.dll` (the game data working directory, usually `util\sources\facade`).
3. Copy **`TripTwins.dll`** and **`trip-twins-test.exe`** into that directory.
4. Start **`trip-twins-test.exe`** instead of the normal starter.
5. The render duplicate starts **ON**. **F8** switches it on/off; **F9** changes which side it appears on. Give the game window keyboard focus.
6. Optional **F6**: after starting a game, enable the staged photo/viewer scene. It places the existing Trip and camera at their captured original introductory poses and hides Grace's body/head drawing. It deliberately changes the scene to make the renderer test easy to inspect. **F8** then gives a one-Trip / two-Trip comparison in that scene. Quit/restart to fully reset poses after using F6.
7. For the comfortably framed screenshot shown here, also copy **`frame-photo.exe`** beside the other files and run it while the game is running. It changes **our mod's photo-camera data**, using its retained COFF symbols, to frame the midpoint of the two renderings at a distance of 190 world units and camera height 65. Return focus to the game. F6 must be ON for that configuration to take effect. The optional command `frame-photo.exe 190 65` makes those defaults explicit. Run the game and tool at the same privilege level.
8. To revert, quit and launch the original starter. Original game files are not overwritten. You can delete the three added files and `trip-twins-test.log`.

The supported original engine's SHA-256 is:

```text
815337c6f7fe05da8a99b5f261a182142907cae6f21b915b03fe6a8c1581016c
```

The launcher refuses a different DLL. Do not load this experiment through an unverified alternate launcher; its member offsets are version-specific. Use an unmodified copy of that engine, not a rebuilt decompilation DLL.

## What the hook does

- Loads the **original `animEngineDLL.dll`**, then the extra experiment DLL.
- Installs the hook **before** entering the original exported `AnimEngineWinMain`.
- Detours the original `DrawSprite` at RVA **`0x8c6a0`** with a nine-byte whole-instruction trampoline. The original prologue is checked.
- Recognizes Trip's body by sprite ID **1**.
- Saves its position through the original, direct virtual getter. It temporarily offsets the verified rendering-position field at **`+0x1424c`** by **85 world units along X**, draws again, and restores the original.
- Draws the attached head (sprite ID **52**, character member **`+0x19c360`**) while the second body's attachment cache is live. Otherwise a body-only duplicate loses its head because the normal head draw is separately scheduled.
- Draws the original body once more after restoration to put its projected/attachment caches back in their normal location.

**Important implementation detail:** the normal temporary duplicate offset does not use `CharacterSprite::SetPosition`. Disassembly showed that that method also overwrites the animation controller's movement target. The duplicate changes only the render-position field within the draw call. **F6 is different:** it deliberately stages the original character and camera through their original native position/rotation methods, called on the engine thread. Position takes four float arguments; rotation takes three. The optional photo scene is not an untouched natural gameplay situation.

## Limits

- **There is still one AI Trip.** The second rendering shares the original model, animation and facial state. It is not a third actor with separate dialogue, navigation, collision or interaction identity.
- No new map or arbitrary asset importer is implemented here.
- The offset copy can be hidden by walls, clipped, or outside the camera's view. Its visibility also depends on the original Trip being scheduled for drawing.
- Extra draw calls cost performance. This is an experimental proof of original-DLL modding, not a production mod framework or a claim that the entire game has been decompiled.
- The engine is patched **in memory** during the test. Its file on disk remains unchanged.

## Build from the included source

On a system with the 32-bit MinGW-w64 C compiler:

```sh
bash build.sh
```

Sources: `trip_twins.c`, `test_launcher.c`, and `frame_photo.c`. The configurator reads the mod DLL's COFF symbols, so **do not strip the DLL's symbol table** if you want to use that tool. The original engine and assets are **not included** in this package.

## Capture environment

The test environment used the original engine, JNI DLL, bundled Windows Java 1.4.2_06, original animations and textures, under **32-bit Wine 10**, Xvfb and software Mesa OpenGL. Original Speex voice files were decoded to WAV for the game's expected playback layout. No replacement renderer, generated character artwork, or composited extra character is involved.

Screenshots are direct lossless screen captures of the original game window. The evidence manifest identifies the capture and executable hashes, the optional F6 staging, and whether the Java backend was temporarily paused to hold the A/B test steady. F6 uses the original introductory camera/character poses inside the original room; there is no image compositing or replacement character artwork. The result is evidence of a render hook, **not** a separate AI character.
