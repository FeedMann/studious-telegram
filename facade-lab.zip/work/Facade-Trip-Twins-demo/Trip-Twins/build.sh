#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
# Requires the MinGW-w64 32-bit C compiler. Original game assets are not built.
CC="${CC:-i686-w64-mingw32-gcc}"
"$CC" -std=c11 -Os -Wall -Wextra -shared -static-libgcc -Wl,--kill-at \
  -o TripTwins.dll trip_twins.c -luser32
"$CC" -std=c11 -Os -Wall -Wextra -mwindows -static-libgcc -Wl,--kill-at \
  -o trip-twins-test.exe test_launcher.c -luser32 -ladvapi32
"$CC" -std=c11 -Os -Wall -Wextra -static-libgcc \
  -o frame-photo.exe frame_photo.c -lkernel32
printf 'Built TripTwins.dll, trip-twins-test.exe and frame-photo.exe (Windows x86).\n'
