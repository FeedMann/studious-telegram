/* Optional photo-camera configurator for OUR TripTwins.dll data only.
 * Finds its private variable RVAs from its own retained COFF symbols, not
 * from guessed addresses or a modified original game DLL.
 * Run beside TripTwins.dll while trip-twins-test.exe is running; F6 stages
 * the scene, and this tool frames both drawings comfortably in the camera.
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
struct Vec3 {float x,y,z;};
static DWORD symbol_rva(const unsigned char *file,size_t size,const char *want) {
    if(size<sizeof(IMAGE_DOS_HEADER))return 0;
    const IMAGE_DOS_HEADER *dos=(const void *)file;
    if(dos->e_magic!=IMAGE_DOS_SIGNATURE || dos->e_lfanew<0 || (size_t)dos->e_lfanew+sizeof(IMAGE_NT_HEADERS32)>size)return 0;
    const IMAGE_NT_HEADERS32 *nt=(const void *)(file+dos->e_lfanew);
    if(nt->Signature!=IMAGE_NT_SIGNATURE || nt->OptionalHeader.Magic!=IMAGE_NT_OPTIONAL_HDR32_MAGIC)return 0;
    DWORD table=nt->FileHeader.PointerToSymbolTable,count=nt->FileHeader.NumberOfSymbols;
    size_t strings=(size_t)table+(size_t)count*18;
    if(strings+4>size)return 0;
    const IMAGE_SECTION_HEADER *secs=(const void *)((const unsigned char *)&nt->OptionalHeader+nt->FileHeader.SizeOfOptionalHeader);
    if((const unsigned char *)(secs+nt->FileHeader.NumberOfSections)>file+size)return 0;
    for(DWORD i=0;i<count;) {
        const unsigned char *s=file+table+(size_t)i*18;
        char name[256]={0};DWORD a,b,value;short section;
        memcpy(&a,s,4);memcpy(&b,s+4,4);memcpy(&value,s+8,4);memcpy(&section,s+12,2);
        if(a==0) {
            if(strings+b<size) {
                size_t n=0;while(n<sizeof(name)-1 && strings+b+n<size && file[strings+b+n])n++;
                memcpy(name,file+strings+b,n);
            }
        } else memcpy(name,s,8);
        if(strcmp(name,want)==0 && section>0 && section<=nt->FileHeader.NumberOfSections)
            return secs[section-1].VirtualAddress+value;
        i+=1+s[17];
    }
    return 0;
}
static int read_at(HANDLE p,uintptr_t a,void *out,SIZE_T n) {
    SIZE_T done=0;return ReadProcessMemory(p,(const void *)a,out,n,&done) && done==n;
}
int main(int argc,char **argv) {
    float distance=argc>1?(float)atof(argv[1]):190.0f;
    float height=argc>2?(float)atof(argv[2]):65.0f;
    if(distance<100 || distance>800 || height<20 || height>150) { puts("Range: distance 100..800, height 20..150.");return 1; }
    FILE *f=fopen("TripTwins.dll","rb");if(!f){puts("Run this tool beside TripTwins.dll.");return 2;}
    fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);
    if(n<=0 || n>10000000){fclose(f);return 3;}
    unsigned char *file=malloc((size_t)n);
    if(!file || fread(file,1,(size_t)n,f)!=(size_t)n){fclose(f);return 3;}fclose(f);
    DWORD pos=symbol_rva(file,(size_t)n,"_intro_camera_pos");
    DWORD rot=symbol_rva(file,(size_t)n,"_intro_camera_rot");
    DWORD trip=symbol_rva(file,(size_t)n,"_intro_trip_pos");
    DWORD saved=symbol_rva(file,(size_t)n,"_intro_saved");
    DWORD side=symbol_rva(file,(size_t)n,"_separation_side");free(file);
    if(!pos || !rot || !trip || !saved || !side){puts("This build lacks the expected photo COFF symbols. Do not strip its symbol table.");return 4;}
    HANDLE s=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);PROCESSENTRY32 pe={0};pe.dwSize=sizeof pe;DWORD pid=0;
    if(Process32First(s,&pe))do {if(_stricmp(pe.szExeFile,"trip-twins-test.exe")==0){pid=pe.th32ProcessID;break;}}while(Process32Next(s,&pe));
    CloseHandle(s);if(!pid){puts("Start trip-twins-test.exe first.");return 5;}
    s=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,pid);MODULEENTRY32 me={0};me.dwSize=sizeof me;uintptr_t base=0;
    if(Module32First(s,&me))do {if(_stricmp(me.szModule,"TripTwins.dll")==0){base=(uintptr_t)me.modBaseAddr;break;}}while(Module32Next(s,&me));
    CloseHandle(s);if(!base){puts("TripTwins.dll not loaded in that test process.");return 6;}
    HANDLE p=OpenProcess(PROCESS_VM_READ|PROCESS_VM_WRITE|PROCESS_VM_OPERATION|PROCESS_QUERY_INFORMATION,FALSE,pid);
    if(!p){puts("Cannot access the test process. Run the game and tool at the same privilege level.");return 7;}
    int initialized=0;LONG sign=1;struct Vec3 cp,cr,tp;
    int ok=read_at(p,base+saved,&initialized,sizeof initialized) && initialized
      && read_at(p,base+rot,&cr,sizeof cr) && read_at(p,base+trip,&tp,sizeof tp)
      && read_at(p,base+side,&sign,sizeof sign);
    if(!ok){CloseHandle(p);puts("Wait for the game's introductory scene to initialize first.");return 8;}
    float radians=cr.y*(3.14159265358979323846f/180.0f);
    cp.x=tp.x+42.5f*(float)sign-distance*sinf(radians);
    cp.y=height;
    cp.z=tp.z+distance*cosf(radians);
    SIZE_T done=0;ok=WriteProcessMemory(p,(void *)(base+pos),&cp,sizeof cp,&done) && done==sizeof cp;
    CloseHandle(p);
    if(!ok){puts("Photo camera data write failed.");return 9;}
    printf("Photo camera framed: X %.2f Y %.2f Z %.2f; yaw %.2f, distance %.1f\n",cp.x,cp.y,cp.z,cr.y,distance);
    puts("Return to the game; F6 stages the scene, F8 toggles the render copy.");
    return 0;
}
