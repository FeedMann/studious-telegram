/* Small native launcher: original engine WinMain + our render hook DLL.
 * Does not replace/rebuild the original engine or JNI bridge.
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wincrypt.h>
#include <stdio.h>
#include <string.h>

typedef int (__cdecl *EngineMain)(HINSTANCE,HINSTANCE,LPSTR,int);
typedef int (__cdecl *InstallFn)(void);

static int correct_original_dll(void) {
    static const unsigned char expected[32]={
      0x81,0x53,0x37,0xc6,0xf7,0xfe,0x05,0xda,0x8a,0x99,0xb5,0xf2,0x61,0xa1,0x82,0x14,
      0x29,0x07,0xca,0xe6,0xf2,0x1b,0x91,0x5b,0x03,0xfe,0x6a,0x8c,0x15,0x81,0x01,0x6c};
    HCRYPTPROV prov=0; HCRYPTHASH hash=0;
    HANDLE f=CreateFileA("animEngineDLL.dll",GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    if(f==INVALID_HANDLE_VALUE) return 0;
    int ok=CryptAcquireContextA(&prov,NULL,NULL,PROV_RSA_AES,CRYPT_VERIFYCONTEXT)
           && CryptCreateHash(prov,CALG_SHA_256,0,0,&hash);
    unsigned char buffer[65536],digest[32];DWORD n=0,size=32;
    if(ok) {
        while(ReadFile(f,buffer,sizeof buffer,&n,NULL) && n) {
            if(!CryptHashData(hash,buffer,n,0)) { ok=0;break; }
        }
    }
    if(ok) ok=CryptGetHashParam(hash,HP_HASHVAL,digest,&size,0) && memcmp(digest,expected,32)==0;
    CloseHandle(f);if(hash)CryptDestroyHash(hash);if(prov)CryptReleaseContext(prov,0);
    return ok;
}

int WINAPI WinMain(HINSTANCE instance,HINSTANCE prev,LPSTR cmd,int show) {
    char path[MAX_PATH];GetModuleFileNameA(NULL,path,MAX_PATH);
    char *slash=strrchr(path,'\\');if(slash) { *slash=0;SetCurrentDirectoryA(path); }
    if(!correct_original_dll()) {
        MessageBoxA(NULL,"Place this test launcher and TripTwins.dll beside the ORIGINAL 1.1b animEngineStarter.exe. The engine hash must match the supported version.","Façade original-engine test",MB_OK|MB_ICONERROR);
        return 1;
    }
    HMODULE engine=LoadLibraryA("animEngineDLL.dll");
    if(!engine) { MessageBoxA(NULL,"Original engine DLL could not load.","Façade test",MB_OK|MB_ICONERROR);return 2; }
    HMODULE mod=LoadLibraryA("TripTwins.dll");
    InstallFn install=mod?(InstallFn)GetProcAddress(mod,"InstallHooks"):NULL;
    if(!install || !install()) { MessageBoxA(NULL,"Render hook could not initialize. See trip-twins-test.log.","Façade test",MB_OK|MB_ICONERROR);return 3; }
    EngineMain main_fn=(EngineMain)GetProcAddress(engine,"?AnimEngineWinMain@@YAHPAUHINSTANCE__@@0PADH@Z");
    if(!main_fn) return 4;
    return main_fn(instance,prev,cmd,show);
}
