/* Original-engine Façade render-only duplicate experiment.
 * Uses the unmodified Windows 1.1b engine DLL and original assets.
 * NOT a new autonomous NPC: the same Trip is drawn at a second position.
 * Addresses/signatures apply ONLY to animEngineDLL.dll SHA-256:
 * 815337c6f7fe05da8a99b5f261a182142907cae6f21b915b03fe6a8c1581016c
 * Run with the provided small launcher; do not substitute for a game DLL.
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>

#if !defined(__i386__)
#error This game and experiment require a 32-bit x86 build.
#endif

#define DRAW_SPRITE_RVA 0x8c6a0u
#define GETPOS_SLOT 11
#define TRIP_ID 1

struct Vec3 { float x, y, z; };
typedef void (__cdecl *DrawSpriteFn)(void *, unsigned char);
typedef struct Vec3 *(__attribute__((thiscall)) *GetPosFn)(void *, struct Vec3 *);
typedef void (__attribute__((thiscall)) *NativePosFn)(void *,float,float,float,float);
typedef void (__attribute__((thiscall)) *NativeRotFn)(void *,float,float,float);
static DrawSpriteFn original_draw;
static unsigned char *engine_base;
static volatile LONG photo_mode=0;
static int intro_saved;
static struct Vec3 intro_camera_pos,intro_camera_rot,intro_trip_pos,intro_trip_rot;
static DWORD photo_frame=0xffffffffu;
static volatile LONG twins_enabled=1;
static volatile LONG stop_worker=0;
static HANDLE worker;
static int in_duplicate;
static LONG logged_trip;
static volatile LONG separation_side=1;

static void log_line(const char *s) {
    FILE *f=fopen("trip-twins-test.log","a");
    if(f) { fprintf(f,"%lu: %s\n",(unsigned long)GetTickCount(),s); fclose(f); }
}

static struct Vec3 read_position(void *sprite) {
    struct Vec3 p={0,0,0};
    uintptr_t *vtable=*(uintptr_t **)sprite;
    ((GetPosFn)vtable[GETPOS_SLOT])(sprite,&p);
    return p;
}
static void set_position(void *sprite, struct Vec3 p) {
    /* Verified original Sprite::GetPosition at RVA 0x1d120 reads this Vec3.
       Do NOT call CharacterSprite's virtual SetPosition: that additionally
       overwrites its animation controller target at offset 0x63938.
       Only change the rendering position, then restore it within this call. */
    memcpy((unsigned char *)sprite+0x1424c,&p,sizeof p);
}

static struct Vec3 read_rotation(void *sprite) {
    struct Vec3 r={0,0,0};
    uintptr_t *vtable=*(uintptr_t **)sprite;
    ((GetPosFn)vtable[12])(sprite,&r);
    return r;
}
static void native_pose(void *sprite,struct Vec3 p,struct Vec3 r) {
    uintptr_t *vt=*(uintptr_t **)sprite;
    ((NativePosFn)vt[15])(sprite,p.x,p.y,p.z,-1.0f);
    /* SetRotation has THREE floats (ret 0x0c), unlike SetPosition's four. */
    ((NativeRotFn)vt[16])(sprite,r.x,r.y,r.z);
}
static void snapshot_and_photo(void *sprite) {
    void *player=*(void **)(engine_base+0x979474);
    void *trip=*(void **)(engine_base+0x979480);
    if(!player || !trip || *(int *)((unsigned char *)player+4)!=2) return;
    if(!intro_saved && sprite==trip) {
        intro_camera_pos=read_position(player);intro_camera_rot=read_rotation(player);
        intro_trip_pos=read_position(trip);intro_trip_rot=read_rotation(trip);
        intro_saved=1;
        char b[250];
        snprintf(b,sizeof b,"Intro snapshot: camera %.2f %.2f %.2f / yaw %.2f; Trip %.2f %.2f %.2f / yaw %.2f",intro_camera_pos.x,intro_camera_pos.y,intro_camera_pos.z,intro_camera_rot.y,intro_trip_pos.x,intro_trip_pos.y,intro_trip_pos.z,intro_trip_rot.y);
        log_line(b);
    }
    if(intro_saved && InterlockedCompareExchange(&photo_mode,0,0)) {
        DWORD frame=*(DWORD *)(engine_base+0x83f62c);
        if(photo_frame!=frame) {
            photo_frame=frame;
            /* A deliberately staged screenshot/viewer scene. Use the original
               native methods on the engine thread; keep Trip + the camera at
               the original intro poses. This is not independent NPC spawning. */
            native_pose(player,intro_camera_pos,intro_camera_rot);
            native_pose(trip,intro_trip_pos,intro_trip_rot);
        }
    }
}

static void __cdecl draw_hook(void *sprite, unsigned char pass) {
    if(sprite && !in_duplicate) {
        snapshot_and_photo(sprite);
        int id=*(int *)((unsigned char *)sprite+4);
        if(InterlockedCompareExchange(&photo_mode,0,0) && (id==0 || id==51)) return;
    }
    if(!sprite || in_duplicate || !InterlockedCompareExchange(&twins_enabled,0,0)
       || *(int *)((unsigned char *)sprite+4)!=TRIP_ID) {
        original_draw(sprite,pass);
        return;
    }
    struct Vec3 p=read_position(sprite);
    struct Vec3 copy=p;
    float separation=85.0f*(float)InterlockedCompareExchange(&separation_side,0,0);
    copy.x+=separation;
    if(InterlockedCompareExchange(&logged_trip,1,0)==0) {
        char b[192];
        snprintf(b,sizeof b,"Original Trip render reached. Position %.3f %.3f %.3f; duplicate offset X=%.1f",p.x,p.y,p.z,separation);
        log_line(b);
    }
    in_duplicate=1;
    original_draw(sprite,pass);
    set_position(sprite,copy);
    original_draw(sprite,pass);
    /* Trip's head is a separately scheduled sprite, attached by the body
       renderer. Draw it while the duplicate's attachment cache is live.
       The body constructor / render function identifies this pointer at
       member offset 0x19c360; head ID is 52 in the original 1.1b engine. */
    void *head=*(void **)((unsigned char *)sprite+0x19c360);
    if(head && *(int *)((unsigned char *)head+4)==52) {
        original_draw(head,pass);
    }
    set_position(sprite,p);
    /* Restore original projected/head caches by drawing the original once more.
       No AI character, callback slot, or permanent object is added. */
    original_draw(sprite,pass);
    in_duplicate=0;
}

static DWORD WINAPI input_worker(void *unused) {
    (void)unused;
    int prev6=0,prev8=0,prev9=0;
    while(!InterlockedCompareExchange(&stop_worker,0,0)) {
        DWORD foreground_pid=0;
        GetWindowThreadProcessId(GetForegroundWindow(),&foreground_pid);
        int k6=foreground_pid==GetCurrentProcessId() && (GetAsyncKeyState(VK_F6)&0x8000);
        if(k6 && !prev6) {
            LONG before=InterlockedCompareExchange(&photo_mode,0,0);
            InterlockedExchange(&photo_mode,!before);
            InterlockedExchange(&logged_trip,0);
            log_line(before?"F6: staged photo scene OFF (restart to fully reset poses)":"F6: staged photo scene ON; original intro camera/Trip poses, Grace hidden");
        }
        int k8=foreground_pid==GetCurrentProcessId() && (GetAsyncKeyState(VK_F8)&0x8000);
        int k9=foreground_pid==GetCurrentProcessId() && (GetAsyncKeyState(VK_F9)&0x8000);
        if(k8 && !prev8) {
            LONG before=InterlockedCompareExchange(&twins_enabled,0,0);
            InterlockedExchange(&twins_enabled,!before);
            InterlockedExchange(&logged_trip,0);
            log_line(before?"F8: render duplicate OFF":"F8: render duplicate ON");
        }
        if(k9 && !prev9) {
            LONG old_side=InterlockedCompareExchange(&separation_side,0,0);
            InterlockedExchange(&separation_side,-old_side);
            InterlockedExchange(&logged_trip,0);
            log_line("F9: duplicate moved to the opposite side");
        }
        prev6=k6;prev8=k8;prev9=k9;
        Sleep(20);
    }
    return 0;
}

__declspec(dllexport) int __cdecl InstallHooks(void) {
    HMODULE engine=GetModuleHandleA("animEngineDLL.dll");
    if(!engine) { log_line("Engine missing; refused."); return 0; }
    engine_base=(unsigned char *)engine;
    unsigned char *target=(unsigned char *)engine+DRAW_SPRITE_RVA;
    const unsigned char expected[9]={0x55,0x8b,0xec,0x81,0xec,0x74,0x05,0x00,0x00};
    if(memcmp(target,expected,9)!=0) { log_line("Original engine prologue mismatch; refused."); return 0; }
    unsigned char *gate=VirtualAlloc(NULL,32,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);
    if(!gate) return 0;
    memcpy(gate,target,9);
    gate[9]=0xe9;
    *(int32_t *)(gate+10)=(int32_t)((uintptr_t)(target+9)-(uintptr_t)(gate+14));
    original_draw=(DrawSpriteFn)gate;
    DWORD old_protect;
    if(!VirtualProtect(target,9,PAGE_EXECUTE_READWRITE,&old_protect)) return 0;
    target[0]=0xe9;
    *(int32_t *)(target+1)=(int32_t)((uintptr_t)draw_hook-(uintptr_t)(target+5));
    memset(target+5,0x90,4);
    FlushInstructionCache(GetCurrentProcess(),target,9);
    DWORD ignored;
    VirtualProtect(target,9,old_protect,&ignored);
    log_line("Native DrawSprite hook installed before original engine WinMain. F8 toggle / F9 side.");
    worker=CreateThread(NULL,0,input_worker,NULL,0,NULL);
    return worker!=NULL;
}

BOOL WINAPI DllMain(HINSTANCE h,DWORD why,void *reserved) {
    (void)reserved;
    if(why==DLL_PROCESS_ATTACH) DisableThreadLibraryCalls(h);
    if(why==DLL_PROCESS_DETACH) InterlockedExchange(&stop_worker,1);
    return TRUE;
}
