#!/usr/bin/env python3
"""Create an annotated compilation; the four separate raw captures stay unedited."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import subprocess,json
root=Path('/home/user/facade-lab');tmp=Path('/home/user/.cache/facade-edit');tmp.mkdir(parents=True,exist_ok=True)
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def f(n,b=False):return ImageFont.truetype(bold if b else font,n)
def run(args):subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','warning',*args],check=True)
enc=['-r','20','-c:v','libx264','-preset','veryfast','-crf','21','-threads','2','-pix_fmt','yuv420p','-c:a','aac','-b:a','96k','-ar','48000','-ac','2']
segments=[]
def card(name,kicker,title,lines,duration):
 im=Image.new('RGB',(1016,734),'#101c25');d=ImageDraw.Draw(im)
 d.rectangle((0,0,1015,9),fill='#57b8ad');d.rounded_rectangle((47,58,969,675),radius=18,outline='#2e454f',width=2)
 d.text((82,97),kicker,font=f(16,True),fill='#65c8bc');d.text((80,161),title,font=f(39,True),fill='#f3eee2')
 for i,line in enumerate(lines):d.text((83,259+i*52),line,font=f(23),fill='#ccd8d9')
 d.line((83,572,930,572),fill='#30464f',width=2);d.text((83,603),'ORIGINAL ENGINE  /  WINE + XVFB  /  FRESH CAPTURES',font=f(15),fill='#deb16e')
 img=tmp/(name+'.png');im.save(img);out=tmp/(name+'.mp4')
 run(['-loop','1','-framerate','20','-i',str(img),'-f','lavfi','-i','anullsrc=r=48000:cl=stereo','-t',str(duration),*enc,str(out)]);segments.append(out)
def clip(name,label):
 path=root/'evidence'/name;labelpath=tmp/(name+'.txt');labelpath.write_text(label)
 out=tmp/('annotated-'+name)
 vf='drawbox=x=0:y=ih-32:w=iw:h=32:color=0x0b1721@0.94:t=fill,drawtext=fontfile='+font+':textfile='+str(labelpath)+':fontsize=15:fontcolor=0xe0e8e1:x=20:y=h-23'
 run(['-i',str(path),'-map','0:v:0','-map','0:a:0','-vf',vf,'-af','aresample=48000:async=1:first_pts=0',*enc,str(out)]);segments.append(out)
card('01-intro','FACADE / MOD LAB  |  14 OCTOBER 2026','World props + a real Java event',[
 'First: new sofa, vase and two room-space wall prints.',
 'Click -> Trip working memory -> JNI gaze request / ACK.',
 'Camera staging is labelled; Java keeps running.',
 'Prototype only: no stock pickup or added collision.'
],4)
clip('04-room-space-java.mp4','ROOM LAB  |  Native projection + depth  |  Mouse -> custom Trip WME + JNI gaze request')
card('02-trip-card','02 / SUPPLIED TRIP TWINS','One Trip AI, rendered twice',[
 'Fresh F8 off/on comparison, then F9 swaps the side.',
 'The same original body/head and character state.',
 'Not a second dialogue agent or autonomous actor.',
 'F6 + frame-photo helper stage this recorded view.'
],3)
clip('02-upstream-trip-twins.mp4','SUPPLIED TRIP  |  F8 off/on + F9 side  |  One AI, two renderings  |  Staged scene')
card('03-obj-card','03 / RECONSTRUCTED UPSTREAM OBJ','A working loader, not a world prop',[
 'Missing build/assets reconstructed for this test.',
 'New sofa asset; NOT the missing original Teto art.',
 'F7 shows/hides; F10 produces a local HI and wobble.',
 'Fixed screen overlay; no Java or story activation.'
],3)
clip('03-repaired-upstream-obj.mp4','RECONSTRUCTED OBJ  |  New sofa test asset  |  F7 / F10 local only  |  Screen overlay')
card('04-vase-card','04 / SUPPLIED CLICKABLE VASE','Real clicks, local-only reaction',[
 'Fresh mouse clicks and F7 visibility toggles.',
 'This supplied vase is a screen-fixed overlay.',
 'No Java WME or stock activation in this version.',
 'The new Room Lab implementation adds that bridge.'
],3)
clip('01-upstream-clickable-vase.mp4','SUPPLIED VASE  |  Real mouse + F7  |  Local mod activation only  |  Staged scene')
card('05-outro','RESULT / TESTED, WITH BOUNDARIES','Source + binaries + launch guide',[
 'Room-space meshes and custom Java activation: yes.',
 'Independent second Trip / stock pickup: no.',
 'Install the original supported game separately.',
 'Uncut captures, event logs and source are in the ZIP.'
],4)
listing=tmp/'concat.txt';listing.write_text(''.join("file '"+str(p)+"'\n" for p in segments))
out=root/'deliverables/facade-mod-demo.mp4';out.parent.mkdir(exist_ok=True)
run(['-f','concat','-safe','0','-i',str(listing),'-c:v','copy','-c:a','aac','-b:a','96k','-af','aresample=48000:async=1:first_pts=0','-movflags','+faststart',str(out)])
print('Created',out)
