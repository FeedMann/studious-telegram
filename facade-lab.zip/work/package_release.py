#!/usr/bin/env python3
"""Assemble and verify a mod-only release; never copy original game payloads."""
from pathlib import Path
import shutil,hashlib,struct,subprocess,json,zipfile
R=Path(__file__).resolve().parent.parent
S=Path('/home/user/.cache/facade-release')/'FacadeModLab'
G=Path('/home/user/.cache/facade-game/util/sources/facade')
EXPECTED='815337c6f7fe05da8a99b5f261a182142907cae6f21b915b03fe6a8c1581016c'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cp(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
def tree(src,dst):shutil.copytree(src,dst,dirs_exist_ok=True)
if S.exists():shutil.rmtree(S)
S.mkdir(parents=True)
# Exact files used by the successful final runtime are the release binaries.
assert digest(G/'animEngineDLL.dll')==EXPECTED
for name in ['FacadeRoomLab.dll','facade-room-lab.exe']:
 assert (R/'room-lab/bin'/name).read_bytes()==(G/name).read_bytes()
for p in (R/'room-lab/java_classes/mod').glob('*.class'):
 assert p.read_bytes()==(G/'../../classes/mod'/p.name).read_bytes()
install=R/'room-lab/install'
for p in (R/'room-lab/bin').iterdir():cp(p,install/'util/sources/facade'/p.name)
tree(R/'room-lab/assets/room_lab',install/'util/sources/facade/room_lab')
for p in (R/'room-lab/java_classes/mod').glob('*.class'):cp(p,install/'util/classes/mod'/p.name)
for name in ['README.md','TEST-RESULTS.md','PROVENANCE.md','START-HERE.txt']:cp(R/name,S/name)
for name in ['README.md','TECHNICAL.md','Install-RoomLab.ps1','Uninstall-RoomLab.ps1']:cp(R/'room-lab'/name,S/'room-lab'/name)
tree(install,S/'room-lab/install')
# New source, not the original engine/stock Java tree.
for name in ['src','java']:tree(R/'room-lab'/name,S/'source/room-lab'/name)
for name in ['build.sh','generate_assets.py']:cp(R/'room-lab'/name,S/'source/room-lab'/name)
(S/'source/room-lab/README.md').write_text('Source for the new Room Lab. Architecture and build: ../../room-lab/TECHNICAL.md.\nFrom this directory, run python3 generate_assets.py then bash build.sh /path/to/Facade.\nCopy rebuilt bin/ and java_classes/mod outputs into the appropriate installed-game paths.\nNo original game classes, rt.jar, engine, audio or art are included.\n')
obj=R/'obj-repaired';od=S/'upstream-experiments/obj-repaired'
for p in (obj/'bin').iterdir():cp(p,od/p.name)
tree(obj/'obj_demo',od/'obj_demo');cp(obj/'README.md',od/'README.md')
tree(obj/'src',S/'source/obj-repaired/src');cp(obj/'build.sh',S/'source/obj-repaired/build.sh')
trip=R/'work/Facade-Trip-Twins-demo/Trip-Twins';td=S/'upstream-experiments/trip-twins'
for name in ['TripTwins.dll','trip-twins-test.exe','frame-photo.exe']:cp(trip/name,td/name)
for name in ['trip_twins.c','test_launcher.c','frame_photo.c','build.sh']:cp(trip/name,S/'source/upstream-trip'/name)
cp(trip/'README.md',S/'source/upstream-trip/UPSTREAM-README.md')
(td/'README.md').write_text('Supplied Trip Twins: copy EXE + DLL beside original 1.1b animEngineDLL.dll and run trip-twins-test.exe.\nF8 duplicate on/off, F9 side, F6 optional staging. frame-photo.exe 190 65 is an optional diagnostic camera helper.\nONE AI, TWO RENDERINGS. Do not stack injectors. Full launch guide: ../../README.md.\nFresh proof: ../../evidence/02-upstream-trip-twins.mp4 and its events/runtime log.\n')
vase=R/'work/Facade-Clickable-Vase-Prototype/facade_interactable_prop';vd=S/'upstream-experiments/clickable-vase'
for p in (vase/'bin').iterdir():cp(p,vd/p.name)
tree(vase/'src',S/'source/upstream-vase/src');cp(vase/'build.sh',S/'source/upstream-vase/build.sh')
cp(vase/'README.md',S/'source/upstream-vase/UPSTREAM-README.md')
(vd/'README.md').write_text('Supplied clickable vase: copy facade-interactable-test.exe + FacadeInteractable.dll beside original 1.1b animEngineDLL.dll; run that EXE.\nMouse click = LOCAL mod reaction only. F7 visibility, F6 optional staged test view.\nFixed-screen overlay, no Java/stock activation. Full launch guide: ../../README.md.\nFresh proof: ../../evidence/01-upstream-clickable-vase.mp4 and its events/runtime log.\n')
for name in ['record_vase.py','record_twins.py','record_obj.py','record_roomlab.py','test_guards.py','create_demo.py']:cp(R/'work'/name,S/'source/test-tools'/name)
cp(R/'analysis/list-poses.c',S/'source/test-tools/list-poses.c')
# Evidence folder is already cleaned to fresh clips, selected proof frames and logs.
tree(R/'evidence',S/'evidence')
# Validate PE architecture, class compatibility, negative/positive tests, and media.
report={'test_date_local':'2026-10-14','original_engine_sha256_after_tests':digest(G/'animEngineDLL.dll'),'room_lab_binaries_match_tested_runtime':True,'native_pe32':{},'java_classes':{},'videos':{},'guard_tests':json.loads((R/'evidence/04-launcher-guard-tests.json').read_text()),'room_lab_event_proof':json.loads((R/'evidence/04-events.json').read_text()),'distribution_excludes_original_game':True}
for p in sorted(S.rglob('*')):
 if not p.is_file():continue
 if p.suffix.lower() in {'.dll','.exe'}:
  b=p.read_bytes();offset=struct.unpack_from('<I',b,0x3c)[0]
  assert b[:2]==b'MZ' and b[offset:offset+4]==b'PE\0\0'
  machine=struct.unpack_from('<H',b,offset+4)[0];magic=struct.unpack_from('<H',b,offset+24)[0]
  assert machine==0x14c and magic==0x10b
  report['native_pe32'][p.relative_to(S).as_posix()]={'machine':'i386','optional_header':'PE32','sha256':digest(p)}
 if p.suffix=='.class':
  b=p.read_bytes();assert b[:4]==b'\xca\xfe\xba\xbe';major=struct.unpack_from('>H',b,6)[0];assert major==48
  assert p.parent.relative_to(S).as_posix()=='room-lab/install/util/classes/mod'
  report['java_classes'][p.name]={'major':major,'sha256':digest(p)}
 assert p.name.lower() not in {'animenginedll.dll','rt.jar','jess.jar','facadeinstaller1.1b.exe'}
 assert p.suffix.lower() not in {'.wav','.spk','.msi','.cab'}
 assert '.git' not in p.relative_to(S).parts and '.cache' not in p.relative_to(S).parts
assert set(report['java_classes'])=={'Main.class','ActivationBridge.class','RoomLabActivationWME.class'}
assert all(g['pass'] for g in report['guard_tests'])
events=report['room_lab_event_proof'];assert events['final_event_sequence']==2 and events['java_ack']=='2 1 1'
assert events['negative_tests']=={'off_triangle_before_first_click':0,'props_hidden_after_first_click':1}
java=(S/'evidence/04-java-runtime.log').read_text();assert java.count('WME VERIFIED seq=')==2 and java.count('JNI RETURNED seq=')==2
for p in sorted((S/'evidence').glob('*.mp4')):
 info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration,size','-show_entries','stream=codec_name,codec_type,width,height,r_frame_rate','-of','json',str(p)],text=True))
 subprocess.run(['ffmpeg','-v','error','-threads','2','-i',str(p),'-f','null','-'],check=True)
 info['sha256']=digest(p);info['complete_decode_passed']=True;report['videos'][p.name]=info
assert len(report['videos'])==4
for filename in ['obj_demo.c','obj_launcher.c']:
 assert (obj/'src'/filename).read_bytes()==(R/'upstream/musical-goggles'/filename).read_bytes()
report['upstream_obj_c_byte_identical']=True
(R/'evidence/verification.json').write_text(json.dumps(report,indent=2)+'\n')
cp(R/'evidence/verification.json',S/'evidence/verification.json')
manifest=''.join(digest(p)+'  '+p.relative_to(S).as_posix()+'\n' for p in sorted(S.rglob('*')) if p.is_file())
(S/'SHA256SUMS.txt').write_text(manifest)
archive=R/'deliverables/facade-mod-lab.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for p in sorted(S.rglob('*')):
  if p.is_file():z.write(p,'FacadeModLab/'+p.relative_to(S).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for line in manifest.splitlines():
  sha,name=line.split('  ',1);assert hashlib.sha256(z.read('FacadeModLab/'+name)).hexdigest()==sha
 assert not any(n.lower().endswith('/animenginedll.dll') for n in z.namelist())
 hashes=[digest(archive)+'  '+archive.name,digest(R/'deliverables/facade-mod-demo.mp4')+'  facade-mod-demo.mp4']
(R/'deliverables/SHA256SUMS.txt').write_text('\n'.join(hashes)+'\n')
print('PASS: exact tested binaries, 3 Java1.4 classes, '+str(len(report['native_pe32']))+' PE32 binaries, 4 fully decoded raw clips, 3 guard cases, real Java round-trip and negative clicks.')
print('PASS: ZIP CRC + every SHA-256 manifest entry; no original engine/JRE/stock classes/game assets.')
print('Archive:',archive,'bytes:',archive.stat().st_size)
print('Files:',len(manifest.splitlines())+1)
print('\n'.join(hashes))
