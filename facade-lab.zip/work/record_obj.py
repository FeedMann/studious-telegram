import subprocess,os,time,pathlib,json
os.environ['DISPLAY']=':99';root=pathlib.Path('/home/user/facade-lab/evidence');events=[]
wid=subprocess.check_output(['xdotool','search','--class','facade-obj-test.exe'],text=True).split()[-1]
p=subprocess.Popen(['ffmpeg','-y','-hide_banner','-loglevel','warning','-f','x11grab','-framerate','20','-video_size','1016x734','-i',':99.0+4,30','-f','pulse','-i','facade_test.monitor','-t','20','-c:v','libx264','-preset','ultrafast','-crf','22','-threads','2','-pix_fmt','yuv420p','-c:a','aac','-b:a','96k','-movflags','+faststart',str(root/'03-repaired-upstream-obj.mp4')],stderr=open(root/'03-recording.log','w'));t=time.monotonic()
def action(note,*args):
 events.append({'time_seconds':round(time.monotonic()-t,2),'action':note});subprocess.run(['xdotool',*args],check=True)
def key(k,note,d=.18):
 action(note,'keydown',k);time.sleep(d);subprocess.run(['xdotool','keyup',k],check=True)
action('Focus normal game; no camera/actor staging in this test','windowactivate','--sync',wid)
time.sleep(2);key('F10','Upstream local greeting/wobble (not Java)');time.sleep(.35)
subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-f','x11grab','-video_size','1016x734','-i',':99.0+4,30','-frames:v','1',str(root/'03-obj-greeting.png')],check=True)
time.sleep(2.3);key('F7','OBJ overlay OFF');time.sleep(2.5);key('F7','OBJ overlay ON');time.sleep(2)
key('Right','Turn original game camera; overlay stays screen-fixed',.65);time.sleep(2.3)
key('Left','Turn back',.65);time.sleep(1);key('F10','Second local greeting');time.sleep(.4)
p.wait(timeout=30)
(root/'03-events.json').write_text(json.dumps({'scope':'Fresh uncut Xvfb; original engine + unchanged upstream OBJ C; new sofa compatibility asset in hardcoded Teto filename; screen overlay, no Java/AI activation; ordinary game camera, not staged','events':events},indent=2))
subprocess.run(['cp','/home/user/.cache/facade-game/util/sources/facade/obj-demo.log',str(root/'03-obj-runtime.log')],check=True)
print('Recorded repaired upstream OBJ')
