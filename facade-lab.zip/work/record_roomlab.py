import subprocess,os,time,pathlib,json,re
os.environ['DISPLAY']=':99';root=pathlib.Path('/home/user/facade-lab/evidence');game=pathlib.Path('/home/user/.cache/facade-game/util/sources/facade');events=[]
wid=subprocess.check_output(['xdotool','search','--class','facade-room-lab.exe'],text=True).split()[-1]
bounds=re.findall(r'vase client bounds ([\d.-]+) ([\d.-]+) ([\d.-]+) ([\d.-]+)',(game/'room-lab.log').read_text())[-1];x0,y0,x1,y1=map(float,bounds);vx=round((x0+x1)/2)+4;vy=round((y0+y1)/2)+30
assert not (game/'room_lab/event.txt').exists(),'Use a fresh launch for an untampered event sequence'
def shot(name):subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-f','x11grab','-video_size','1016x734','-i',':99.0+4,30','-frames:v','1',str(root/name)],check=True)
def seq():
 p=game/'room_lab/event.txt';return int(p.read_text().split()[0]) if p.exists() else 0
p=subprocess.Popen(['ffmpeg','-y','-hide_banner','-loglevel','warning','-f','x11grab','-framerate','20','-video_size','1016x734','-i',':99.0+4,30','-f','pulse','-i','facade_test.monitor','-t','42','-c:v','libx264','-preset','ultrafast','-crf','22','-threads','2','-pix_fmt','yuv420p','-c:a','aac','-b:a','96k','-movflags','+faststart',str(root/'04-room-space-java.mp4')],stderr=open(root/'04-recording.log','w'));t=time.monotonic()
def action(note,*args):
 events.append({'time_seconds':round(time.monotonic()-t,2),'action':note});subprocess.run(['xdotool',*args],check=True)
def key(k,note,d=.18):
 action(note,'keydown',k);time.sleep(d);subprocess.run(['xdotool','keyup',k],check=True)
def click(x,y,note):
 action(note,'mousemove',str(x),str(y));time.sleep(.18);subprocess.run(['xdotool','mousedown','1'],check=True);time.sleep(.2);subprocess.run(['xdotool','mouseup','1'],check=True)
action('Focus original engine; F6 staged camera labelled on HUD; Java running','windowactivate','--sync',wid)
time.sleep(2);shot('04-world-props.png')
click(650,600,'Negative: off-triangle background click');time.sleep(.45);assert seq()==0
click(vx,vy,'Real left click on projected world vase, event #1');time.sleep(.5);assert seq()==1;shot('04-java-ack.png')
time.sleep(2);key('F7','Hide world sofa and vase');time.sleep(.5);click(vx,vy,'Negative: click former vase location while props hidden');time.sleep(.5);assert seq()==1;shot('04-props-off.png')
time.sleep(1);key('F7','Restore world props');time.sleep(1.3)
key('F9','World wall posters OFF');time.sleep(1.8);key('F9','World wall posters ON');time.sleep(1.4)
key('F5','Stage camera 45 world units sideways; meshes exhibit parallax');time.sleep(1);shot('04-world-side.png');time.sleep(1.4);key('F5','Restore original staged angle');time.sleep(1.2)
key('F8','Coordinated render-only Trip twin ON (still one AI)');time.sleep(2);shot('04-world-twin.png');key('F8','Render-only Trip twin OFF');time.sleep(.9)
click(vx,vy,'Second real click on room-space vase');time.sleep(.65);assert seq()==2;shot('04-java-ack-2.png')
key('F6','Disable pose/camera staging; allow ordinary game input');time.sleep(.6);key('Right','Actually turn live camera with game input',.42);key('Up','Actually move live camera with game input',.35);time.sleep(1);shot('04-live-camera.png')
key('F6','Restore explicitly labelled staged demo view');time.sleep(1);key('F5','Final alternative staged angle');time.sleep(.5)
p.wait(timeout=45)
ack=(game/'room_lab/ack.txt').read_text().strip();assert ack=='2 1 1',ack
(root/'04-events.json').write_text(json.dumps({'scope':'Fresh uncut Xvfb capture; original engine + new room meshes + original Java backend through additive wrapper. F6 staging disclosed in HUD; no independent second AI, native Sprite registration, collision or pickup. ACK proves WME insertion and JNI return, not sustained gaze.','vase_root_click':[vx,vy],'negative_tests':{'off_triangle_before_first_click':0,'props_hidden_after_first_click':1},'final_event_sequence':seq(),'java_ack':ack,'events':events},indent=2))
for src,dst in [('room-lab.log','04-roomlab-runtime.log'),('room-lab-launch.log','04-roomlab-launch.log'),('room_lab/java-bridge.log','04-java-runtime.log'),('room_lab/event.txt','04-event.txt'),('room_lab/ack.txt','04-ack.txt')]:subprocess.run(['cp',str(game/src),str(root/dst)],check=True)
print('Recorded room-space/Java demo; two mouse activations and two verified negative tests; Java ACK:',ack)
