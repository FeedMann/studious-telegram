import subprocess,os,time,pathlib,json
os.environ['DISPLAY']=':99';root=pathlib.Path('/home/user/facade-lab/evidence');events=[]
p=subprocess.Popen(['ffmpeg','-y','-hide_banner','-loglevel','warning','-f','x11grab','-framerate','20','-video_size','1016x734','-i',':99.0+4,30','-f','pulse','-i','facade_test.monitor','-t','19','-c:v','libx264','-preset','ultrafast','-crf','22','-threads','2','-pix_fmt','yuv420p','-c:a','aac','-b:a','96k','-movflags','+faststart',str(root/'02-upstream-trip-twins.mp4')],stderr=open(root/'02-recording.log','w'));t=time.monotonic()
def key(k,note):
 events.append({'time_seconds':round(time.monotonic()-t,2),'action':note});subprocess.run(['xdotool','keydown',k],check=True);time.sleep(.18);subprocess.run(['xdotool','keyup',k],check=True)
subprocess.run(['xdotool','windowactivate','--sync','12582915'],check=True)
time.sleep(3);key('F8','Duplicate OFF, one original AI Trip');time.sleep(3.5)
key('F8','Duplicate ON, same Trip body/head drawn twice');time.sleep(3.5)
subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-f','x11grab','-video_size','1016x734','-i',':99.0+4,30','-frames:v','1',str(root/'02-twins-on.png')],check=True)
key('F9','Flip duplicate offset side');time.sleep(3);key('F9','Restore original side');p.wait(timeout=25)
(root/'02-events.json').write_text(json.dumps({'scope':'Fresh uncut Xvfb capture; F6 and frame-photo 190 65 stage camera/Trip; Grace hidden; Java NOT paused; one AI character, two renderings','events':events},indent=2))
subprocess.run(['cp','/home/user/.cache/facade-game/util/sources/facade/trip-twins-test.log',str(root/'02-twins-runtime.log')],check=True)
print('Recorded Trip Twins A/B')
