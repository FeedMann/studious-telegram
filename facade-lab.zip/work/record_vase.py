import os, subprocess, time, pathlib, json
os.environ['DISPLAY']=':99'
root=pathlib.Path('/home/user/facade-lab/evidence')
vid=root/'01-upstream-clickable-vase.mp4'
events=[]
def action(note,*args):
    events.append({'time_seconds':round(time.monotonic()-t,2),'action':note})
    subprocess.run(['xdotool',*args],check=True)
def shot(name):
    subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-f','x11grab','-video_size','1016x734','-i',':99.0+4,30','-frames:v','1',str(root/name)],check=True)
p=subprocess.Popen(['ffmpeg','-y','-hide_banner','-loglevel','warning','-f','x11grab','-framerate','20','-video_size','1016x734','-i',':99.0+4,30','-f','pulse','-i','facade_test.monitor','-t','20','-c:v','libx264','-preset','ultrafast','-crf','22','-threads','2','-pix_fmt','yuv420p','-c:a','aac','-b:a','96k','-movflags','+faststart',str(vid)],stderr=open(root/'01-recording.log','w'))
t=time.monotonic()
action('Focus original game window','windowactivate','--sync','12582915')
time.sleep(2)
action('Hover vase at native-client x825 y257','mousemove','829','287')
time.sleep(1.2)
action('Left button down on mod-owned hit target','mousedown','1');time.sleep(.2);action('Left button up','mouseup','1')
time.sleep(.25);shot('01-vase-clicked.png')
time.sleep(2.8)
action('Hide vase with F7','keydown','F7');time.sleep(.15);action('Release F7','keyup','F7')
time.sleep(2.2)
action('Show vase with F7','keydown','F7');time.sleep(.15);action('Release F7','keyup','F7')
time.sleep(2.1)
action('Second click','mousedown','1');time.sleep(.18);action('Release second click','mouseup','1')
time.sleep(2.2);action('Move pointer off target','mousemove','300','600')
p.wait(timeout=30)
(root/'01-events.json').write_text(json.dumps({'scope':'Fresh uncut Xvfb capture; F6 staged camera; Java not paused; vase overlay/mod-only activation','events':events},indent=2))
subprocess.run(['cp','/home/user/.cache/facade-game/util/sources/facade/facade-interactable-prop.log',str(root/'01-vase-runtime.log')],check=True)
print('Recorded',vid)
