import pathlib,shutil,subprocess,os,time,json
root=pathlib.Path('/home/user/facade-lab');game=pathlib.Path('/home/user/.cache/facade-game');scratch=pathlib.Path('/home/user/.cache/facade-guard-tests');out=[]
env=dict(os.environ,DISPLAY=':99',WINEARCH='win32',WINEPREFIX='/home/user/.cache/facade-wine',WINEDEBUG='-all',LIBGL_ALWAYS_SOFTWARE='1',LP_NUM_THREADS='2')
for name,expected in [('wrong-engine',2),('missing-java',3),('missing-assets',3)]:
 d=scratch/name/'util'/'sources'/'facade';d.mkdir(parents=True,exist_ok=True)
 shutil.copy2(root/'room-lab/bin/facade-room-lab.exe',d/'facade-room-lab.exe')
 if name=='wrong-engine': (d/'animEngineDLL.dll').write_bytes(b'not an original engine')
 else:shutil.copy2(game/'util/sources/facade/animEngineDLL.dll',d/'animEngineDLL.dll')
 if name=='missing-assets':
  classes=scratch/name/'util/classes/mod';classes.mkdir(parents=True,exist_ok=True)
  for p in (root/'room-lab/java_classes/mod').glob('*.class'):shutil.copy2(p,classes/p.name)
 p=subprocess.Popen(['wine',str(d/'facade-room-lab.exe')],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 window=subprocess.check_output(['xdotool','search','--sync','--onlyvisible','--name','Room Lab'],env=env,text=True,timeout=15).split()[-1]
 subprocess.run(['xdotool','windowactivate','--sync',window],env=env,check=True)
 subprocess.run(['xdotool','keydown','Return'],env=env,check=True);time.sleep(.18);subprocess.run(['xdotool','keyup','Return'],env=env,check=True)
 stdout,stderr=p.communicate(timeout=15);log=(d/'room-lab-launch.log').read_text(errors='replace')
 result={'case':name,'expected_exit':expected,'actual_exit':p.returncode,'pass':p.returncode==expected,'log':log};out.append(result)
 print(name,p.returncode,'PASS' if result['pass'] else 'FAIL',log.replace('\n',' | '))
(root/'evidence/04-launcher-guard-tests.json').write_text(json.dumps(out,indent=2))
assert all(r['pass'] for r in out)
